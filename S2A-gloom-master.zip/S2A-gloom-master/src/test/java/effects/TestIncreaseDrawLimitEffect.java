package effects;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.easymock.EasyMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import gameplay.Player;
import gameplay.Turn;

class TestIncreaseDrawLimitEffect {
	
	Effect effect;
	Player player;
	
	@BeforeEach
	void setup() {
		effect = new ChangeDrawLimitEffect(1);
		player = EasyMock.createMock(Player.class);
	}

	@Test
	void testImmediateEffect() {
		player.changeDrawLimit(1);
		
		EasyMock.replay(player);
		effect.doImmediateEffect(player);
		
		EasyMock.verify(player);
	}
	
	@Test
	void testEndEffect() {
		player.changeDrawLimit(-1);
		
		EasyMock.replay(player);
		effect.endEffect(player);
		
		EasyMock.verify(player);
	}
	
	@Test
	void testEndEffectWithNegative() {
		
		Effect effect = new ChangeDrawLimitEffect(4);
		player.changeDrawLimit(-4); 
		//EasyMock.expect(1); 
		
		EasyMock.replay(player);
		effect.endEffect(player);
		
		EasyMock.verify(player);
	}
	
	@Test
	void testModifyTurn() {
		Turn turn = EasyMock.createMock(Turn.class);
		
		EasyMock.replay(turn);
		Turn output = effect.modifyTurn(turn);
		
		EasyMock.verify(turn);
		assertEquals(turn, output);
	}
	


}
