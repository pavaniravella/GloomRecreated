package effects;

import static org.junit.jupiter.api.Assertions.*;

import org.easymock.EasyMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import effects.Effect;
import effects.SkipDrawPhaseEffect;
import gameplay.Player;
import gameplay.SkipDrawPhaseTurn;
import gameplay.StandardTurn;
import gameplay.Turn;

class TestSkipDrawPhaseEffect {
	
	Effect effect;
	
	@BeforeEach
	void setup() {
		this.effect = new SkipDrawPhaseEffect();
	}

	@Test
	void testSkipDrawPhase() {
		StandardTurn turn = EasyMock.createMock(StandardTurn.class);
		
		EasyMock.replay(turn);
		Turn output = effect.modifyTurn(turn);
		
		assertTrue(output instanceof SkipDrawPhaseTurn);
	}
	
	@Test
	void testSkipDrawPhaseStillActive() {
		StandardTurn turn = EasyMock.createMock(StandardTurn.class);
		
		EasyMock.replay(turn);
		effect.modifyTurn(turn);
		Turn output = effect.modifyTurn(turn);
		
		assertEquals(turn, output);
	}
	
	@Test
	void testEndEffect() {
		Player player = EasyMock.createMock(Player.class);
		
		EasyMock.replay(player);
		effect.endEffect(player);
		
		EasyMock.verify(player);
	}
	
	@Test
	void testDoImmediateEffect() {
		Player player = EasyMock.createMock(Player.class);
		
		EasyMock.replay(player);
		effect.doImmediateEffect(player);
		
		EasyMock.verify(player);
	}

	@Test
	void testSkipDrawPhaseEndEffect() {
		Effect effect = new SkipDrawPhaseEffect();
		Player player = EasyMock.createMock(Player.class);
		effect.endEffect(player); 
		EasyMock.replay(player);
		EasyMock.verify(player); 
		
	}
	
	@Test
	void testSkipDrawPhaseDoImmediateEffect() {
		Effect effect = new SkipDrawPhaseEffect();
		Player player = EasyMock.createMock(Player.class);
		effect.doImmediateEffect(player); 
		EasyMock.replay(player);
		EasyMock.verify(player); 
		
	}
}
