package effects;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.easymock.EasyMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import gameplay.Player;
import gameplay.Turn;

class TestCompositeEffect {
	
	Effect effect1;
	Effect effect2;
	Effect effect3;
	Effect effect;
	
	@BeforeEach
	void setup() {
		effect1 = EasyMock.createMock(Effect.class);
		effect2 = EasyMock.createMock(Effect.class);
		effect3 = EasyMock.createMock(Effect.class);
		effect = new CompositeEffect(effect1, effect2, effect3);
	}

	@Test
	void testModifyTurn() {
		Turn turn = EasyMock.createMock(Turn.class);
		EasyMock.expect(effect1.modifyTurn(turn)).andReturn(turn);
		EasyMock.expect(effect2.modifyTurn(turn)).andReturn(turn);
		EasyMock.expect(effect3.modifyTurn(turn)).andReturn(turn);
		
		EasyMock.replay(effect1, effect2, effect3, turn);
		Turn output = effect.modifyTurn(turn);
		
		assertEquals(turn, output);
		EasyMock.verify(effect1, effect2, effect3, turn);
	}
	
	@Test
	void testDoImmediateSideEffect() {
		Player player = EasyMock.createMock(Player.class);
		effect1.doImmediateEffect(player);
		effect2.doImmediateEffect(player);
		effect3.doImmediateEffect(player);

		EasyMock.replay(effect1, effect2, effect3, player);
		effect.doImmediateEffect(player);
		
		EasyMock.verify(effect1, effect2, effect3, player);
	}
	
	@Test
	void testEndEffect() {
		Player player = EasyMock.createMock(Player.class);
		effect1.endEffect(player);
		effect2.endEffect(player);
		effect3.endEffect(player);

		EasyMock.replay(effect1, effect2, effect3, player);
		effect.endEffect(player);

		EasyMock.verify(effect1, effect2, effect3, player);
	}

}
