package effects;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import effects.DiscardHandEffect;
import effects.DoNothingEffect;
import effects.Effect;
import effects.EffectFactory;
import effects.SkipDrawPhaseEffect;

class TestEffectFactory {
	
	EffectFactory effectFactory;
	
	@BeforeEach
	void setup() {
		effectFactory = new EffectFactory();
	}

	@Test
	void testGetSkipDrawPhaseEffect() {
		Effect effect = effectFactory.getEffect("SkipDrawPhase");
		
		assertTrue(effect instanceof SkipDrawPhaseEffect);
	}
	
	@Test
	void testGetDoNothingEffect() {
		Effect effect = effectFactory.getEffect("");
		
		assertTrue(effect instanceof DoNothingEffect);
	}
	
	@Test
	void testGetDiscardHandEffect() {
		Effect effect = effectFactory.getEffect("DiscardHand");
		
		assertTrue(effect instanceof DiscardHandEffect);
	}
	
	@Test
	void testGetDiscardHandAndSkipDrawPhaseEffect() {
		Effect effect = effectFactory.getEffect("DiscardHandAndSkipDrawPhase");
		
		assertTrue(effect instanceof CompositeEffect);
		CompositeEffect compositeEffect = (CompositeEffect) effect;
		boolean containsDiscardHand = false;
		boolean containsSkipDrawPhase = false;
		for(Effect innerEffect : compositeEffect.effects) {
			if(innerEffect instanceof DiscardHandEffect) {
				containsDiscardHand = true;
			} else if (innerEffect instanceof SkipDrawPhaseEffect) {
				containsSkipDrawPhase = true;
			}
		}
		assertTrue(containsDiscardHand);
		assertTrue(containsSkipDrawPhase);
		assertEquals(2, compositeEffect.effects.size());
	}
	
	@Test
	void testGetIncreaseDrawLimitEffect() {
		Effect effect = effectFactory.getEffect("IncreaseDrawLimitEffect");
		
		assertTrue(effect instanceof ChangeDrawLimitEffect);
	}
	
	@Test
	void testGetDecreaseDrawLimitEffect() {
		Effect effect = effectFactory.getEffect("DecreaseDrawLimitEffect");
		
		assertTrue(effect instanceof ChangeDrawLimitEffect);
	}
	
	@Test
	void testGetDrawThreeCardsEffect() {
		Effect effect = effectFactory.getEffect("DrawThreeCards");
		
		assertTrue(effect instanceof DrawCardsEffect);
	}
	
	@Test
	void testGetOneCardForEachDuckIconInPlay() {
		Effect effect = effectFactory.getEffect("DrawOneCardForEachDuckIconInPlay");
		
		assertTrue(effect instanceof  DrawCardForEachDuckIconInPlayEffect);
	}
	@Test
	void testGetDrawTwoCardsEffect() {
		Effect effect = effectFactory.getEffect("DrawTwoCards");
		
		assertTrue(effect instanceof DrawCardsEffect);
		DrawCardsEffect castEffect = (DrawCardsEffect) effect;
		assertEquals(2, castEffect.numberOfCards);
	}
	
	@Test
	void testGetDiscardOneCardEffect() {
		Effect effect = effectFactory.getEffect("DiscardOneCard");
		
		assertTrue(effect instanceof DiscardCardsEffect);
		DiscardCardsEffect castEffect = (DiscardCardsEffect) effect;
		assertEquals(1, castEffect.numberOfCards);
	}
	
	@Test
	void testGetDiscardThreeCardsEffect() {
		Effect effect = effectFactory.getEffect("DiscardThreeCards");
		
		assertTrue(effect instanceof DiscardCardsEffect);
		DiscardCardsEffect castEffect = (DiscardCardsEffect) effect;
		assertEquals(3, castEffect.numberOfCards);
	}

}
