package effects;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.easymock.EasyMock;
import org.junit.jupiter.api.Test;

import gameplay.DrawCardsOnSetupTurn;
import gameplay.Player;
import gameplay.Turn;

class TestDrawCardsEffect {
	
	@Test
	void testModifyTurn() {
		Effect effect = new DrawCardsEffect(2);
		Turn turn = EasyMock.createMock(Turn.class);
		Turn output = effect.modifyTurn(turn);
		assertTrue(output instanceof DrawCardsOnSetupTurn);
	}
	
	@Test
	void testEndEffect() {
		Effect effect = new DrawCardsEffect(2); 
		Player player = EasyMock.createMock(Player.class);
		effect.endEffect(player); 
		EasyMock.replay(player);
		EasyMock.verify(player); 
		
	}
	
	@Test
	void testDoImmediateEffect() {
		Effect effect = new DrawCardsEffect(2); 
		Player player = EasyMock.createMock(Player.class);
		effect.doImmediateEffect(player); 
		EasyMock.replay(player);
		EasyMock.verify(player); 
		
	}
	
	
}
