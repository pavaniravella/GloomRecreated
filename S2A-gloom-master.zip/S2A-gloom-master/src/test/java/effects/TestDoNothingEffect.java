package effects;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.easymock.EasyMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import effects.DoNothingEffect;
import effects.Effect;
import gameplay.Player;
import gameplay.StandardTurn;
import gameplay.Turn;

class TestDoNothingEffect {
	
	Effect effect;
	
	@BeforeEach
	void setup() {
		this.effect = new DoNothingEffect();
	}

	@Test
	void testDrawPhase() {
		Effect effect = new DoNothingEffect();
		StandardTurn turn = EasyMock.createMock(StandardTurn.class);
		
		EasyMock.replay(turn);
		Turn output = effect.modifyTurn(turn);
		
		assertEquals(turn, output);
	}
	
	@Test
	void testEndEffect() {
		Player player = EasyMock.createMock(Player.class);
		
		EasyMock.replay(player);
		effect.endEffect(player);
		
		EasyMock.verify(player);
	}
	
	@Test
	void testDoImmediateEffect() {
		Player player = EasyMock.createMock(Player.class);
		
		EasyMock.replay(player);
		effect.doImmediateEffect(player);
		
		EasyMock.verify(player);
	}

}
