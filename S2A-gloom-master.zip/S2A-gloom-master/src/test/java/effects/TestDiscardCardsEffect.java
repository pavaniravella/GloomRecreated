package effects;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.easymock.EasyMock;
import org.junit.jupiter.api.Test;

import gameplay.Player;
import gameplay.Turn;

class TestDiscardCardsEffect {

	@Test
	void testDoImmediateEffect() {
		Effect effect = new DiscardCardsEffect(1);
		Player player = EasyMock.createMock(Player.class);
		player.discardCards(1);
		
		EasyMock.replay(player);
		effect.doImmediateEffect(player);
		
		EasyMock.verify(player);
	}
	
	@Test
	void testModifyTurn() {
		Effect effect = new DiscardCardsEffect(1);
		Turn turn = EasyMock.createMock(Turn.class);
		
		EasyMock.replay(turn);
		Turn output = effect.modifyTurn(turn);
		
		EasyMock.verify(turn);
		assertEquals(turn, output);
	}
	
	@Test
	void testSkipDrawPhaseEndEffect() {
		Effect effect = new DiscardCardsEffect(1); 
		Player player = EasyMock.createMock(Player.class);
		effect.endEffect(player); 
		EasyMock.replay(player);
		EasyMock.verify(player); 
		
	}

}
