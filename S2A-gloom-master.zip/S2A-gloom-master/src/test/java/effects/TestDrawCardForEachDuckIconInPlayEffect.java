package effects;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.easymock.EasyMock;
import org.junit.jupiter.api.Test;

import gameplay.DrawCardsOnSetupTurn;
import gameplay.Player;
import gameplay.Turn;

class TestDrawCardForEachDuckIconInPlayEffect {

	@Test
	void testDo() {
		Effect effect = new DrawCardForEachDuckIconInPlayEffect();
		Turn turn = EasyMock.createMock(Turn.class);
		
		EasyMock.expect(turn.countNumberDuckIconsInPlay()).andReturn(3);
		
		EasyMock.replay(turn);
		Turn newTurn = effect.modifyTurn(turn);
		
		EasyMock.verify(turn);
		assertTrue(newTurn instanceof DrawCardsOnSetupTurn);
	}
	
	@Test
	void doImmediateEffect() {
		Effect effect = new DrawCardForEachDuckIconInPlayEffect();
		Player player = EasyMock.createMock(Player.class);
		effect.doImmediateEffect(player);
		EasyMock.replay(player);
		EasyMock.verify(player);
	}
	

	@Test
	void endEffect() {
		Effect effect = new DrawCardForEachDuckIconInPlayEffect();
		Player player = EasyMock.createMock(Player.class);
		effect.endEffect(player);
		EasyMock.replay(player);
		EasyMock.verify(player);
	}
	



}
