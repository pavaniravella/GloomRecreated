package effects;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.easymock.EasyMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import effects.DiscardHandEffect;
import effects.Effect;
import gameplay.Player;
import gameplay.Turn;

class TestDiscardHandEffect {

	Effect effect;

	@BeforeEach
	void setup() {
		this.effect = new DiscardHandEffect();
	}

	@Test
	void testImmediateEffect() {
		Player player = EasyMock.createMock(Player.class);
		player.discardHand();

		EasyMock.replay(player);
		effect.doImmediateEffect(player);

		EasyMock.verify(player);
	}

	@Test
	void testModifyTurn() {
		Effect effect = new DiscardHandEffect();
		Turn turn = EasyMock.createMock(Turn.class);

		EasyMock.replay(turn);
		Turn output = effect.modifyTurn(turn);

		EasyMock.verify(turn);
		assertEquals(turn, output);
	}

	@Test
	void testEndEffect() {
		Effect effect = new DiscardHandEffect();
		Player player = EasyMock.createMock(Player.class);
		effect.endEffect(player);
		EasyMock.replay(player);
		EasyMock.verify(player);

	}
}
