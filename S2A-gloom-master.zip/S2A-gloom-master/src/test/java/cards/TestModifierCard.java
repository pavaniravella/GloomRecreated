package cards;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.easymock.EasyMock;
import org.junit.jupiter.api.Test;

import effects.DoNothingEffect;
import effects.Effect;
import gameplay.Player;

class TestModifierCard {

	@Test
	void testGetName() {
		String expected = "";
		Card card = new ModifierCard(null, "Dummy Title", "Dummy Description", "Dummy EffectDescription", null, null, null, null, null, new DoNothingEffect());
		
		String name = card.getName();
		
		assertEquals(expected, name);
	}
	
	@Test
	void testGetNameAfterPlay() {
		String expected = "AAAA";
		Card newInnerCard = EasyMock.createMock(Card.class);
		EasyMock.expect(newInnerCard.getName()).andReturn(expected);
		Card card = new ModifierCard(null, "Dummy Title", "Dummy Description", "Dummy EffectDescription", null, null, null, null, null, new DoNothingEffect());
		
		EasyMock.replay(newInnerCard);
		card.playCardOn(newInnerCard);
		String name = card.getName();
		
		EasyMock.verify(newInnerCard);
		assertEquals(expected, name);
	}
	
	@Test
	void testGetTitle() {
		String expected = "Dummy Title";
		Card card = new ModifierCard(null, expected, "Dummy Description", "Dummy EffectDescription", null, null, null, null, null, new DoNothingEffect());
		
		String title = card.getTitle();
		
		assertEquals(expected, title);
	}
	
	@Test
	void testGetDescription() {
		String expected = "Dummy Description";
		Card card = new ModifierCard(null, "Dummy Title", expected, "Dummy EffectDescription", null, null, null, null, null, new DoNothingEffect());
		
		String description = card.getDescription();
		
		assertEquals(expected, description);
	}
	
	@Test
	void testGetEffectDescription() {
		String expected = "Dummy EffectDescription";
		Card card = new ModifierCard(null, "Dummy Title", "Dummy Description", expected, null, null, null, null, null, new DoNothingEffect());

		String description = card.getEffectDescription();

		assertEquals(expected, description);
	}

	@Test
	void testCanPlayOnValid() {
		Card toPlayOn = EasyMock.createMock(Card.class);
		EasyMock.expect(toPlayOn.isAlive()).andReturn(true);
		Card card = new ModifierCard(null, "Dummy Title", "Dummy Description", "Dummy EffectDescription", null, null, null, null, null, new DoNothingEffect());
		
		EasyMock.replay(toPlayOn);
		boolean canPlayOn = card.canPlayOn(toPlayOn, 1);
		
		EasyMock.verify(toPlayOn);
		assertTrue(canPlayOn);
	}
	
	@Test
	void testCanPlayOnInvalid() {
		Card toPlayOn = EasyMock.createMock(Card.class);
		EasyMock.expect(toPlayOn.isAlive()).andReturn(false);
		Card card = new ModifierCard(null, "Dummy Title", "Dummy Description", "Dummy EffectDescription", null, null, null, null, null, new DoNothingEffect());
		
		EasyMock.replay(toPlayOn);
		boolean canPlayOn = card.canPlayOn(toPlayOn, 1);
		
		EasyMock.verify(toPlayOn);
		assertFalse(canPlayOn);
	}
	
	@Test
	void testGetType() {
		Card card = new ModifierCard(null, "Dummy Title", "Dummy Description", "Dummy EffectDescription", null, null, null, null, null, new DoNothingEffect());
		
		String type = card.getType();
		
		assertEquals("Modifier", type);
	}
	
	@Test
	void testPlayCardOn() {
		Effect effect = EasyMock.createMock(Effect.class);
		Card toPlayOn = EasyMock.createMock(Card.class);
		Card card = new ModifierCard(null, "Dummy Title", "Dummy Description", "Dummy EffectDescription", null, null, null, null, null, effect);
		
		EasyMock.replay(effect);
		Card newCard = card.playCardOn(toPlayOn);
		
		assertEquals(card, newCard);
		EasyMock.verify(effect);
	}
	
	@Test
	void testGetPoints1() {
		Card card = new ModifierCard(null, "Dummy Title", "Dummy Description", "Dummy EffectDescription", -15, null, null, null, null, new DoNothingEffect());
		
		int points = card.getPoints1();
		
		assertEquals(-15, points);
	}
	
	@Test
	void testGetEmptyPoints1AfterPlay() {
		Card toPlayOn = EasyMock.createMock(Card.class);
		EasyMock.expect(toPlayOn.getPoints1()).andReturn(-10);
		Card card = new ModifierCard(null, "Dummy Title", "Dummy Description", "Dummy EffectDescription", null, null, null, null, null, new DoNothingEffect());
		
		EasyMock.replay(toPlayOn);
		card.playCardOn(toPlayOn);
		int points = card.getPoints1();
		
		EasyMock.verify(toPlayOn);
		assertEquals(-10, points);
	}
	
	@Test
	void testGetNonEmptyPoints1AfterPlay() {
		Card toPlayOn = EasyMock.createMock(Card.class);
		Card card = new ModifierCard(null, "Dummy Title", "Dummy Description", "Dummy EffectDescription", -15, null, null, null, null, new DoNothingEffect());
		
		EasyMock.replay(toPlayOn);
		card.playCardOn(toPlayOn);
		int points = card.getPoints1();
		
		EasyMock.verify(toPlayOn);
		assertEquals(-15, points);
	}
	

	@Test
	void testGetPoints2() {
		Card card = new ModifierCard(null, "Dummy Title", "Dummy Description", "Dummy EffectDescription", null, -15, null, null, null, new DoNothingEffect());
		
		int points = card.getPoints2();
		
		assertEquals(-15, points);
	}
	
	@Test
	void testGetEmptyPoints2AfterPlay() {
		Card toPlayOn = EasyMock.createMock(Card.class);
		EasyMock.expect(toPlayOn.getPoints2()).andReturn(-10);
		Card card = new ModifierCard(null, "Dummy Title", "Dummy Description", "Dummy EffectDescription", null, null, null, null, null, new DoNothingEffect());
		
		EasyMock.replay(toPlayOn);
		card.playCardOn(toPlayOn);
		int points = card.getPoints2();
		
		EasyMock.verify(toPlayOn);
		assertEquals(-10, points);
	}
	
	@Test
	void testGetNonEmptyPoints2AfterPlay() {
		Card toPlayOn = EasyMock.createMock(Card.class);
		Card card = new ModifierCard(null, "Dummy Title", "Dummy Description", "Dummy EffectDescription", null, -15, null, null, null, new DoNothingEffect());
		
		EasyMock.replay(toPlayOn);
		card.playCardOn(toPlayOn);
		int points = card.getPoints2();
		
		EasyMock.verify(toPlayOn);
		assertEquals(-15, points);
	}
	

	@Test
	void testGetPoints3() {
		Card card = new ModifierCard(null, "Dummy Title", "Dummy Description", "Dummy EffectDescription", null, null, -15, null, null, new DoNothingEffect());
		
		int points = card.getPoints3();
		
		assertEquals(-15, points);
	}
	
	@Test
	void testGetEmptyPoints3AfterPlay() {
		Card toPlayOn = EasyMock.createMock(Card.class);
		EasyMock.expect(toPlayOn.getPoints3()).andReturn(-10);
		Card card = new ModifierCard(null, "Dummy Title", "Dummy Description", "Dummy EffectDescription", null, null, null, null, null, new DoNothingEffect());
		
		EasyMock.replay(toPlayOn);
		card.playCardOn(toPlayOn);
		int points = card.getPoints3();
		
		EasyMock.verify(toPlayOn);
		assertEquals(-10, points);
	}
	
	@Test
	void testGetNonEmptyPoints3AfterPlay() {
		Card toPlayOn = EasyMock.createMock(Card.class);
		Card card = new ModifierCard(null, "Dummy Title", "Dummy Description", "Dummy EffectDescription", null, null, -15, null, null, new DoNothingEffect());
		
		EasyMock.replay(toPlayOn);
		card.playCardOn(toPlayOn);
		int points = card.getPoints3();
		
		EasyMock.verify(toPlayOn);
		assertEquals(-15, points);
	}
	
	@Test
	void testCleanUpOnCover() {
		Effect effect = EasyMock.createMock(Effect.class);
		Card toPlayOn = new ModifierCard(null, "Dummy Title", "Dummy Description", "Dummy EffectDescription", null, null, null, null, null, effect);
		Player player = EasyMock.createMock(Player.class);
		effect.endEffect(player);
		
		EasyMock.replay(effect);
		toPlayOn.cleanUpOnCover(player);
		
		EasyMock.verify(effect);	
	}
	
	@Test
	void testDoImmediateSideEffect() {
		Effect effect = EasyMock.createMock(Effect.class);
		Card card = new ModifierCard(null, "Dummy Title", "Dummy Description", "Dummy EffectDescription", null, null, null, null, null, effect);
		Player player = EasyMock.createMock(Player.class);
		effect.doImmediateEffect(player);
		
		EasyMock.replay(effect, player);
		card.doImmediateSideEffect(player);
		
		EasyMock.verify(effect, player);
	}

}
