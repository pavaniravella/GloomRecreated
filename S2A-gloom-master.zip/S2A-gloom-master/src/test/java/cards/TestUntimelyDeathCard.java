package cards; 
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import org.easymock.EasyMock;
import org.junit.jupiter.api.Test;

import effects.DoNothingEffect;
import gameplay.Player;

class TestUntimelyDeathCard {
	
	Card innerCard;
	Card card;
	Card characterCard;

	@Test
	void testGetNameBeforePlay() {
		String expected = "";
		card = new UntimelyDeathCard(null, "Dummy Title", "Dummy Description", "Dummy EffectDescription", null, null, null, null, null, new DoNothingEffect());
		
		String name = card.getName();
		
		assertEquals(expected, name);
	}
	
	@Test
	void testGetNameAfterPlay() {
		getNameAfterPlay("Lord Slogar");
	}
	
	@Test
	void testGetEmptyNameAfterPlay() {
		getNameAfterPlay("");
	}

	@Test
	void testGetDescription() {
		String expectedDescription = "At least you had a last supper.";
		getDescription(expectedDescription);
	}
	
	@Test
	void testGetEmptyDescription() {
		String expectedDescription = "";
		getDescription(expectedDescription);
	}
	
	@Test
	void testGetDescriptionAfterPlay() {
		String expectedDescription = "At least you had a last supper.";
		setupAfterPlay("Dummy Title", expectedDescription);
		
		EasyMock.replay(innerCard);
		String name = card.getDescription();
		
		assertEquals(expectedDescription, name);
		EasyMock.verify(innerCard);
	}
	
	@Test
	void testGetTitle() {
		getTitle("Choked on a Bone");
	}
	
	@Test
	void testGetEmptyTitle() {
		getTitle("");
	}
	
	@Test
	void testGetTitleAfterPlay() {
		String expected = "Choked on a Bone";
		getTitleAfterPlay(expected);
	}
	
	@Test
	void testGetEmptyTitleAfterPlay() {
		String expected = "";
		getTitleAfterPlay(expected);
	}
	
	@Test
	void testGetType() {
		card = new UntimelyDeathCard(null, "Dummy Title", "Dummy Description", "Dummy EffectDescription", null, null, null, null, null, new DoNothingEffect());
		
		String type = card.getType();
		
		assertEquals("Untimely Death", type);
	}
	
	@Test
	void testGetStoryIconString() {
		card = new UntimelyDeathCard(null, "Dummy Title", "Dummy Description", "Dummy EffectDescription", null, null, null, null, null, new DoNothingEffect());
		
		String storyIconString = card.getStoryIconString();
		
		assertEquals("Blank", storyIconString);
	}
	
	@Test
	void testGetStoryIconStringAfterPlay() {
		setupAfterPlay("Dummy Title", "Dummy Description");
		String expected = "Romance";
		EasyMock.expect(innerCard.getStoryIconString()).andReturn(expected);
		
		EasyMock.replay(innerCard);
		String name = card.getStoryIconString();
		
		assertEquals(expected, name);
		EasyMock.verify(innerCard);
	}
	
	@Test
	void testCleanUpOnCover() {
		card = new UntimelyDeathCard(null, "Dummy Title", "Dummy Description", null, null, null, null, null, null, new DoNothingEffect());
		Player player = EasyMock.createMock(Player.class);
		
		EasyMock.replay(player);
		card.cleanUpOnCover(player);
		
		EasyMock.verify(player);
	}

	private void getTitleAfterPlay(String expected) {
		setupAfterPlay(expected, "Dummy Description");
		
		EasyMock.replay(innerCard);
		String name = card.getTitle();
		
		assertEquals(expected, name);
		EasyMock.verify(innerCard);
	}
	
	private void getDescription(String expectedDescription) {
		card = new UntimelyDeathCard(null, "Dummy Title", expectedDescription, "Dummy EffectDescription", null, null, null, null, null, new DoNothingEffect());
		
		String description = card.getDescription();
		
		assertEquals(expectedDescription, description);
	}

	private void getNameAfterPlay(String expected) {
		setupAfterPlay(expected, "Dummy Description");
		EasyMock.expect(innerCard.getName()).andReturn(expected);
		
		EasyMock.replay(innerCard);
		String name = card.getName();
		
		assertEquals(expected, name);
		EasyMock.verify(innerCard);
	}

	private void getTitle(String expectedTitle) {
		card = new UntimelyDeathCard(null, expectedTitle, "Dummy Description", "Dummy EffectDescription", null, null, null, null, null, new DoNothingEffect());
		
		String output = card.getTitle();
		
		assertEquals(expectedTitle, output);
	}
	
	private void setupAfterPlay(String title, String description) {
		innerCard = EasyMock.createMock(Card.class);
		card = new UntimelyDeathCard(innerCard, title, description);
	}
	
	@Test
	void testPlayCardOnNegativeCharacter() {
		card = new UntimelyDeathCard(null, "Dummy Title", "Dummy Description");
		CharacterCard famCard = new CharacterCard("Dummy Name", "Dummy Title", "Dummy Description", "Dummy EffectDescription", -10, null, null, "Dummy Family", null, null);
	    Card notDeadFamCard = card.playCardOn(famCard);
	    assertFalse(notDeadFamCard.isAlive());
	}
	
	@Test
	void testPlayCardOnNonNegativeCharacter() {
		card = new UntimelyDeathCard(null, "Dummy Title", "Dummy Description", "Dummy EffectDescription", null, null, null, null, null, null);
		CharacterCard familyCard = new CharacterCard("Dummy Name", "Dummy Title", "Dummy Description", "Dummy EffectDescription", 0, null, null, "Dummy Family", null, null);
	    try {
			card.playCardOn(familyCard);
			fail();
	    } catch(InvalidCardPlayException e) { }
	}
	
	@Test
	void testPlayCardOnDeadCharacter() {
		card = new UntimelyDeathCard(null, "Dummy Title", "Dummy Description");
		CharacterCard famCard = new CharacterCard("Dummy Name", "Dummy Title", "Dummy Description", "Dummy EffectDescription", -10, null, null, "Dummy Family", null, null);
	    Card killedCard = card.playCardOn(famCard);
	    try {
			card.playCardOn(killedCard);
			fail();
	    } catch(InvalidCardPlayException e) { }
	}
	
	@Test
	void testCanPlayCardOnNegativeCharacter() {
		card = new UntimelyDeathCard(null, "Dummy Title", "Dummy Description", "Dummy EffectDescription", null, null, null, null, null, null);
		CharacterCard famCard = new CharacterCard("Dummy Name", "Dummy Title", "Dummy Description", "Dummy EffectDescription", -10, null, null, "Dummy Family", null, null);
		boolean canPlay = card.canPlayOn(famCard, 1);
		assertTrue(canPlay);
	}
	
	@Test
	void testCanPlayCardOnNonNegativeCharacter() {
		card = new UntimelyDeathCard(null, "Dummy Title", "Dummy Description", "Dummy EffectDescription", null, null, null, null, null, null);
		CharacterCard famCard = new CharacterCard("Dummy Name", "Dummy Title", "Dummy Description", "Dummy EffectDescription", 0, null, null, "Dummy Family", null, null);
		boolean canPlay = card.canPlayOn(famCard, 1);
		assertFalse(canPlay);
	}
	
	@Test
	void testCanPlayCardOnDeadCharacter() {
		card = new UntimelyDeathCard(null, "Dummy Title", "Dummy Description");
		CharacterCard famCard = new CharacterCard("Dummy Name", "Dummy Title", "Dummy Description", "Dummy EffectDescription", -10, null, null, "Dummy Family", null, null);
	    Card killedCard = card.playCardOn(famCard);
	    boolean canPlay = card.canPlayOn(killedCard, 1);
	    assertFalse(canPlay);
	}
	
	@Test
	void testGetPoints1() {
		card = new UntimelyDeathCard(null, "Dummy Title", "Dummy Description");
		int beforePoints = card.getPoints1();
		assertEquals(0, beforePoints);
		
		setupAfterPlay("Dummy Title", "Dummy Description");
		EasyMock.expect(innerCard.getPoints1()).andReturn(1);
		
		EasyMock.replay(innerCard);
		int afterPoints = card.getPoints1();
		
		assertEquals(1, afterPoints);
	}
	
	@Test
	void testGetPoints2() {
		card = new UntimelyDeathCard(null, "Dummy Title", "Dummy Description");
		int beforePoints = card.getPoints2();
		assertEquals(0, beforePoints);
		
		setupAfterPlay("Dummy Title", "Dummy Description");
		EasyMock.expect(innerCard.getPoints2()).andReturn(2);
		
		EasyMock.replay(innerCard);
		int afterPoints = card.getPoints2();
		
		assertEquals(2, afterPoints);
	}
	
	@Test
	void testGetPoints3() {
		card = new UntimelyDeathCard(null, "Dummy Title", "Dummy Description");
		int beforePoints = card.getPoints3();
		assertEquals(0, beforePoints);
		
		setupAfterPlay("Dummy Title", "Dummy Description");
		EasyMock.expect(innerCard.getPoints3()).andReturn(3);
		
		EasyMock.replay(innerCard);
		int afterPoints = card.getPoints3();
		
		assertEquals(3, afterPoints);
	}
	
	@Test
	void testGetTotalPoints() {
		card = new UntimelyDeathCard(null, "Dummy Title", "Dummy Description");
		int beforePoints = card.getTotalPoints();
		assertEquals(0, beforePoints);
		
		setupAfterPlay("Dummy Title", "Dummy Description");
		EasyMock.expect(innerCard.getTotalPoints()).andReturn(6);
		EasyMock.expect(innerCard.getPoints3()).andReturn(3);
		EasyMock.expect(innerCard.getPoints2()).andReturn(2);
		EasyMock.expect(innerCard.getPoints1()).andReturn(1);
		
		EasyMock.replay(innerCard);
		int afterPoints = card.getTotalPoints();
		
		assertEquals(6, afterPoints);
	}

	@Test
	void testGetEffectDescription() {
		card = new UntimelyDeathCard(null, "Dummy Title", "Dummy Description","Dummy Effectdescription", null, null, null, null, null, new DoNothingEffect());

		String effectDescription = card.getEffectDescription();

		assertEquals("Dummy Effectdescription", effectDescription);
	}
}