package cards;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestInvalidCardPlayException {

	@Test
	void testGetMessage() {
		try {
			throw new InvalidCardPlayException();
		} catch(InvalidCardPlayException e) {
			String message = e.getMessage();
			assertEquals("Can't play character card on character card.", message);
		}
	}

}
