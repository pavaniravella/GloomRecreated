package cards; 

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.easymock.EasyMock;
import org.junit.jupiter.api.Test;

import effects.DoNothingEffect;
import gameplay.Player;

class TestCharacterCard {
	
	@Test
	void testGetSpecificPoints1() {
		Integer expectedPoints = -15;
		CharacterCard card = new CharacterCard("Dummy Name", "Dummy Title", "Dummy Description", null, expectedPoints, null, null, "Dummy Family", null, new DoNothingEffect());
		
		Integer points = card.getPoints1();
		
		assertEquals(expectedPoints, points);
	}
	
	@Test
	void testGetEmptyPoints1() {
		Integer expectedPoints = 0;
		CharacterCard card = new CharacterCard("Dummy Name", "Dummy Title", "Dummy Description", null, null, null, null, "Dummy Family", null, new DoNothingEffect());
		
		Integer points = card.getPoints1();
		
		assertEquals(expectedPoints, points);
	}
	
	@Test
	void testGetSpecificPoints2() {
		Integer expectedPoints = -15;
		CharacterCard card = new CharacterCard("Dummy Name", "Dummy Title", "Dummy Description", null, null, expectedPoints, null, "Dummy Family", null, new DoNothingEffect());
		
		Integer points = card.getPoints2();
		
		assertEquals(expectedPoints, points);
	}
	@Test
	void testCleanupOnCover() {
		Card card = new CharacterCard(null, "Dummy Title", "Dummy Description", null, null, null, null, null, null, new DoNothingEffect());
		Player player = EasyMock.createMock(Player.class); 
		EasyMock.replay(player); 
		EasyMock.verify(player); 
	}
	
	@Test
	void testGetEmptyPoints2() {
		Integer expectedPoints = 0;
		CharacterCard card = new CharacterCard("Dummy Name", "Dummy Title", "Dummy Description", null, null, null, null, "Dummy Family", null, new DoNothingEffect());
		
		Integer points = card.getPoints2();
		
		assertEquals(expectedPoints, points);
	}
	
	@Test
	void testGetSpecificPoints3() {
		Integer expectedPoints = -15;
		CharacterCard card = new CharacterCard("Dummy Name", "Dummy Title", "Dummy Description", null, null, null, expectedPoints, "Dummy Family", null, new DoNothingEffect());
		
		Integer points = card.getPoints3();
		
		assertEquals(expectedPoints, points);
	}
	
	@Test
	void testGetEmptyPoints3() {
		Integer expectedPoints = 0;
		CharacterCard card = new CharacterCard("Dummy Name", "Dummy Title", "Dummy Description", null, null, null, null, "Dummy Family", null, new DoNothingEffect());
		
		Integer points = card.getPoints3();
		
		assertEquals(expectedPoints, points);
	}
	
	@Test
	void testGetNonEmptyDescription() {
		String expectedDescription = "Description";
		testGetDescription(expectedDescription);
	}
	
	
	@Test
	void testGetEmptyDescription() {
		String expectedDescription = "";
		testGetDescription(expectedDescription);
	}
	
	@Test
	void testGetNonEmptyTitle() {
		String expectedTitle = "Title";
		testGetTitle(expectedTitle);
	}
	
	@Test
	void testGetEmptyTitle() {
		String expectedTitle = "";
		testGetTitle(expectedTitle);
	}
	
	@Test
	void testGetEffectDescription() {
		CharacterCard card = new CharacterCard("Dummy Name", "Dummy Title",  "Dummy Description", null, null, null, null, "Dummy Family", null, new DoNothingEffect());
		
		String EffectDescription = card.getEffectDescription();
		
		assertEquals(null, EffectDescription);
	}
	
	
	@Test
	void testGetStoryIconString() {
		CharacterCard card = new CharacterCard("Dummy Name", "Dummy Title", "Dummy Description", null, null, null, null, "Dummy Family", null, new DoNothingEffect());
		
		String storyIconString = card.getStoryIconString();
		
		assertEquals("Blank", storyIconString);
	}
	
	@Test
	void testGetType() {
		CharacterCard card = new CharacterCard("Dummy Name", "Dummy Title", "Dummy Description", null, null, null, null, "Dummy Family", null, new DoNothingEffect());
		
		String type = card.getType();
		
		assertEquals("Character", type);
	}

	@Test
	void testGetNonEmptyName() {
		String expectedName = "Name";
		testGetName(expectedName);
	}
	
	@Test
	void testGetEmptyName() {
		String expectedName = "";
		testGetName(expectedName);
	}
	
	@Test
	void testCleanUpOnCover() {
		CharacterCard card = new CharacterCard("Dummy Name", "Dummy Title", "Dummy Description", null, null, null, null, "Dummy Family", null, new DoNothingEffect());
		Player player = EasyMock.createMock(Player.class);
		
		EasyMock.replay(player);
		card.cleanUpOnCover(player);
		
		EasyMock.verify(player);
	}

	private void testGetName(String expectedName) {
		CharacterCard card = new CharacterCard(expectedName, "Dummy Title", "Dummy Description", null, null, null, null, "Dummy Family", null, new DoNothingEffect());
		
		String name = card.getName();
		
		assertEquals(expectedName, name);
	}
	
	private void testGetTitle(String expectedTitle) {
		CharacterCard card = new CharacterCard("Dummy Name", expectedTitle, "Dummy Description", null, null, null, null, "Dummy Family", null, new DoNothingEffect());
		
		String title = card.getTitle();
		
		assertEquals(expectedTitle, title);
	}
	
	private void testGetDescription(String expectedDescription) {
		CharacterCard card = new CharacterCard("Dummy Name", "Dummy Title", expectedDescription, null, null, null, null, "Dummy Family", null, new DoNothingEffect());
		
		String name = card.getDescription();
		
		assertEquals(expectedDescription, name);
	}
	
}
