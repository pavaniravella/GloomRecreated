package cards;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TestEmptyInnerCard {

	Card card;
	
	@BeforeEach
	void setup() {
		card = new EmptyInnerCard();
	}
	
	@Test
	void testGetDescription() {
		String description = card.getDescription();
		
		assertNull(description);
	}
	
	@Test
	void testGetTitle() {
		String title = card.getTitle();
		
		assertNull(title);
	}
	
	@Test
	void testGetType() {
		String type = card.getType();
		
		assertEquals("Empty", type);
	}
	
	@Test
	void testGetEffectDescription() {
		String effectDescription = card.getEffectDescription();

		assertNull(effectDescription);
	}

}
