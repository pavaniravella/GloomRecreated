package cards;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.easymock.EasyMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TestCardLimitCanPlayOn {

	Card card;
	Card innerCard;
	
	@BeforeEach
	void setup() {
		innerCard = EasyMock.createMock(Card.class);
		card = new CardLimitCanPlayOn("Test String", innerCard);
	}
	
	@Test
	void testGetName() {
		String testString = "Test";
		EasyMock.expect(innerCard.getName()).andReturn(testString);
		
		EasyMock.replay(innerCard);
		String output = card.getName();
		
		EasyMock.verify(innerCard);
		assertEquals(testString, output);
	}
	
	@Test
	void testGetDescription() {
		String testString = "Test";
		EasyMock.expect(innerCard.getDescription()).andReturn(testString);
		
		EasyMock.replay(innerCard);
		String output = card.getDescription();
		
		EasyMock.verify(innerCard);
		assertEquals(testString, output);
	}
	
	@Test
	void testGetTitle() {
		String testString = "Test";
		EasyMock.expect(innerCard.getTitle()).andReturn(testString);
		
		EasyMock.replay(innerCard);
		String output = card.getTitle();
		
		EasyMock.verify(innerCard);
		assertEquals(testString, output);
	}
	
	@Test
	void testGetStoryIconString() {
		String testString = "Test";
		EasyMock.expect(innerCard.getStoryIconString()).andReturn(testString);
		
		EasyMock.replay(innerCard);
		String output = card.getStoryIconString();
		
		EasyMock.verify(innerCard);
		assertEquals(testString, output);
	}
	
	@Test
	void testCanPlayOnValid() {
		Card otherCard = EasyMock.createMock(Card.class);
		EasyMock.expect(otherCard.getStoryIconString()).andReturn("Test String");
		
		EasyMock.replay(innerCard, otherCard);
		boolean output = card.canPlayOn(otherCard, 0);
		
		EasyMock.verify(innerCard, otherCard);
		assertTrue(output);
	}
	
	@Test
	void testCanPlayOnInvalid() {
		Card otherCard = EasyMock.createMock(Card.class);
		EasyMock.expect(otherCard.getStoryIconString()).andReturn("Incorrect Test String");
		
		EasyMock.replay(innerCard, otherCard);
		boolean output = card.canPlayOn(otherCard, 0);
		
		EasyMock.verify(innerCard, otherCard);
		assertFalse(output);
	}
	
	@Test
	void testGetPoints1() {
		int points1 = -5;
		EasyMock.expect(innerCard.getPoints1()).andReturn(points1);
		
		EasyMock.replay(innerCard);
		int output = card.getPoints1();
		
		EasyMock.verify(innerCard);
		assertEquals(points1, output);
	}
	
	@Test
	void testGetPoints2() {
		int points2 = -5;
		EasyMock.expect(innerCard.getPoints2()).andReturn(points2);
		
		EasyMock.replay(innerCard);
		int output = card.getPoints2();
		
		EasyMock.verify(innerCard);
		assertEquals(points2, output);
	}
	
	@Test
	void testGetPoints3() {
		int points3 = -5;
		EasyMock.expect(innerCard.getPoints3()).andReturn(points3);
		
		EasyMock.replay(innerCard);
		int output = card.getPoints3();
		
		EasyMock.verify(innerCard);
		assertEquals(points3, output);
	}
	
	@Test
	void testIsAliveTrue() {
		EasyMock.expect(innerCard.isAlive()).andReturn(true);
		
		EasyMock.replay(innerCard);
		boolean output = card.isAlive();
		
		EasyMock.verify(innerCard);
		assertTrue(output);
	}
	
	@Test
	void testIsAliveFalse() {
		EasyMock.expect(innerCard.isAlive()).andReturn(false);
		
		EasyMock.replay(innerCard);
		boolean output = card.isAlive();
		
		EasyMock.verify(innerCard);
		assertFalse(output);
	}
	
	@Test
	void testPlayCardOn() {
		Card toPlayOn = EasyMock.createMock(Card.class);
		EasyMock.expect(innerCard.playCardOn(toPlayOn)).andReturn(innerCard);
		
		EasyMock.replay(innerCard, toPlayOn);
		Card output = card.playCardOn(toPlayOn);
		
		EasyMock.verify(innerCard);
		assertEquals(card, output);
		CardLimitCanPlayOn castCard = (CardLimitCanPlayOn) output;
		assertEquals(innerCard, castCard.innerCard);
	}

	@Test
	void testGetTypeOfCard() {
		innerCard = new ModifierCard("Dummy Name", "Dummy Title", "Dummy DEscription", null, 0, 0, 0, null, null, null); 
		card = new CardLimitCanPlayOn("Test String", innerCard);
		String type = card.getType(); 
		String expected = "Modifier"; 
		assertEquals(expected, type); 
		
	}
	
	@Test
	void testGetEffectDescription() {
		String effectDescription = card.getEffectDescription();
		assertNull(effectDescription);
	}
}
