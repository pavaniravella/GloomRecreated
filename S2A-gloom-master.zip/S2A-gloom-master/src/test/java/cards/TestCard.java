package cards;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import org.easymock.EasyMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import effects.DoNothingEffect;
import gameplay.Player;
import gameplay.Turn;

class TestCard {
	
	Card card;
	
	@BeforeEach
	void setup() {
		card = new EmptyInnerCard();
	}
	
	@Test
	void testGetPoints1() {
		int points = card.getPoints1();
		
		assertEquals(0, points);
	}
	
	@Test
	void testGetPoints2() {
		int points = card.getPoints2();
		
		assertEquals(0, points);
	}
	
	@Test
	void testGetPoints3() {
		int points = card.getPoints3();
		
		assertEquals(0, points);
	}
	
	@Test
	void testGetEffectDescription() {
		String effectDescription = card.getEffectDescription();

		assertNull(effectDescription);
	}
	
	@Test
	void testGetAlive() {
		boolean isAlive = card.isAlive();
		
		assertTrue(isAlive);
	}
	
	@Test
	void testCanPlayOn() {
		Card otherCard = EasyMock.createMock(Card.class);
		
		boolean canPlayOn = card.canPlayOn(otherCard, 1);
		
		assertFalse(canPlayOn);
	}
	
	@Test
	void testGetTotalPoints() {
		card = new ModifierCard(null, null, null, null, 1, 2, 3, null, null, new DoNothingEffect());
		
		int totalPoints = card.getTotalPoints();
		
		assertEquals(6, totalPoints);
	}
	
	@Test
	void testDoSideEffectTurnChanges() {
		Turn turn = EasyMock.createMock(Turn.class);
		
		Turn output = card.doSideEffectTurnChanges(turn);
		
		assertEquals(turn, output);
	}
	
	@Test
	void testPlayCardOnThrowsInvalidCardPlayException() {
		Card otherCard = EasyMock.createMock(Card.class);
		try {
			card.playCardOn(otherCard);
			fail("playCardOn should default to throwing InvalidCardPlayException");
		} catch(InvalidCardPlayException e) {
			assertEquals("Can't play character card on character card.", e.getMessage());
		}
	}
	
	@Test
	void testGetStoryIconString() {
		String storyIconString = card.getStoryIconString();
		
		assertEquals("Blank", storyIconString);
	}
	
	@Test
	void testCleanUpOnCover() {
		Player player = EasyMock.createMock(Player.class);
		
		EasyMock.replay(player);
		card.cleanUpOnCover(player);
		
		EasyMock.verify(player);
	}
	
	@Test
	void testDoImmediateSideEffect() {
		Player player = EasyMock.createMock(Player.class);
		
		EasyMock.replay(player);
		card.doImmediateSideEffect(player);
		
		EasyMock.verify(player);
	}
	
}
