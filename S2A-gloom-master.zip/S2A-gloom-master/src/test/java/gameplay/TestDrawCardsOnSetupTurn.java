package gameplay;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.easymock.EasyMock;
import org.junit.jupiter.api.Test;

import cards.Card;

class TestDrawCardsOnSetupTurn {

	@Test
	void testConstructor() {
		Turn innerTurn = EasyMock.createMock(Turn.class);
		
		EasyMock.replay(innerTurn);
		DrawCardsOnSetupTurn turn = new DrawCardsOnSetupTurn(2, innerTurn);
		
		EasyMock.verify(innerTurn);
		assertEquals(innerTurn, turn.innerTurn);
	}
	
	@Test
	void testDoPreTurnOperations() {
		Turn innerTurn = EasyMock.createMock(Turn.class);
		Turn turn = new DrawCardsOnSetupTurn(2, innerTurn);
		List<Card> deck = new ArrayList<Card>();
		Card card1 = EasyMock.createMock(Card.class);
		Card card2 = EasyMock.createMock(Card.class);
		deck.add(card1);
		deck.add(card2);
		List<Player> players = new ArrayList<Player>();
		Player player = EasyMock.createMock(Player.class);
		innerTurn.doPreTurnOperations(deck, players, player);
		player.forceAddToHand(card1);
		player.forceAddToHand(card2);
		
		EasyMock.replay(innerTurn, card1, card2, player);
		turn.doPreTurnOperations(deck, players, player);
		
		EasyMock.verify(innerTurn, card1, card2, player);
		assertEquals(0, deck.size());
		
	}

}
