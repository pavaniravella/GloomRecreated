package gameplay;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.ArrayList;
import java.util.List;

import org.easymock.EasyMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import cards.Card;
import cards.CharacterCard;
import gui.MainGameGUI;

class TestPlayer {

	Player player;
	MainGameGUI gui;
	List<Card> family;
	List<Card> hand;
	String[] names = new String[] { "Name", "Name", "Name", "Name", "Name" };
	String[] titles = new String[] { "Title", "Title", "Title", "Title", "Title" };
	String[] descriptions = new String[] { "Description", "Description", "Description", "Description", "Description" };
	String[] points1 = new String[] { "0", "0", "0", "0", "0" };
	String[] points2 = new String[] { "0", "0", "0", "0", "0" };
	String[] points3 = new String[] { "0", "0", "0", "0", "0" };
	String[] effectDescriptions = new String[] {"Effects", "Effects", "Effects", "Effects", "Effects" };
	
	@BeforeEach
	void setup() {
		family = new ArrayList<Card>();
		for (int i = 0; i < 5; i++) {
			Card mock = EasyMock.createMock(CharacterCard.class);
			family.add(mock);
		}
		hand = new ArrayList<Card>();
		for (int i = 0; i < 5; i++) {
			Card mock = EasyMock.createMock(Card.class);
			hand.add(mock);
		}
		gui = EasyMock.createMock(MainGameGUI.class);
		player = new Player("Dummy Name", family, hand, gui, "South");
	}
	
	@Test
	void testGetPlayerName() {
		String name = player.getPlayerName();
		assertEquals(name, "Dummy Name");
	}
	
	@Test
	void testGetPoints() {
		String[] expected1 = new String[] { "0", "1", "2" , "3", "4" };
		String[] expected2 = new String[] { "1", "2", "3" , "4", "5" };
		String[] expected3 = new String[] { "-1", "0", "1", "2" , "3" };
		for(int i = 0; i < 5; i++) {
			EasyMock.expect(family.get(i).getPoints1()).andReturn(i);
			EasyMock.expect(family.get(i).getPoints2()).andReturn(i+1);
			EasyMock.expect(family.get(i).getPoints3()).andReturn(i-1);
		}
		
		for(int i = 0; i < 5; i++) {
			EasyMock.replay(family.get(i));
		}
		
		String[] actual1 = player.getPoints(family, 1);
		String[] actual2 = player.getPoints(family, 2);
		String[] actual3 = player.getPoints(family, 3);
		for(int i = 0; i < 5; i++) {
			assertEquals(expected1[i], actual1[i]);
			assertEquals(expected2[i], actual2[i]);
			assertEquals(expected3[i], actual3[i]);
		}
	}

	@Test
	void testDisplayHand() {
		gui.displayHand(EasyMock.aryEq(new String[] { "", "", "", "", "" }), EasyMock.aryEq(descriptions),
				EasyMock.aryEq(titles), EasyMock.aryEq(points1), EasyMock.aryEq(points2), 
				EasyMock.aryEq(points3), EasyMock.aryEq(effectDescriptions));;

		for (Card card : hand) {
			EasyMock.expect(card.getName()).andReturn("");
			EasyMock.expect(card.getTitle()).andReturn("Title");
			EasyMock.expect(card.getDescription()).andReturn("Description");
			EasyMock.expect(card.getPoints1()).andReturn(0);
			EasyMock.expect(card.getPoints2()).andReturn(0);
			EasyMock.expect(card.getPoints3()).andReturn(0);
			EasyMock.expect(card.getEffectDescription()).andReturn("Effects");
		}
		EasyMock.replay(hand.toArray());

		EasyMock.replay(gui);
		player.displayHand();

		EasyMock.verify(hand.toArray());
		EasyMock.verify(gui);
	}

	@Test
	void testDisplayFamily() {
		gui.displayFamilyCards(EasyMock.anyString(), EasyMock.aryEq(names), EasyMock.aryEq(descriptions),
				EasyMock.aryEq(titles), EasyMock.aryEq(points1), EasyMock.aryEq(points2), 
				EasyMock.aryEq(points3));

		for (Card card : family) {
			EasyMock.expect(card.getName()).andReturn("Name");
			EasyMock.expect(card.getTitle()).andReturn("Title");
			EasyMock.expect(card.getDescription()).andReturn("Description");
			EasyMock.expect(card.getPoints1()).andReturn(0);
			EasyMock.expect(card.getPoints2()).andReturn(0);
			EasyMock.expect(card.getPoints3()).andReturn(0);
		}
		EasyMock.replay(family.toArray());

		EasyMock.replay(gui);
		player.displayFamily();

		EasyMock.verify(family.toArray());
		EasyMock.verify(gui);
	}

	@Test
	void testChangeLocation2Players() {
		player.changeLocation(2);
		assertEquals(player.location, "North");
		player.changeLocation(2);
		assertEquals(player.location, "South");
	}
	
	@Test
	void testChangeLocation3Players() {
		player.changeLocation(3);
		assertEquals(player.location, "North");
		player.changeLocation(3);
		assertEquals(player.location, "East");
		player.changeLocation(3);
		assertEquals(player.location, "South");
	}
	
	@Test
	void testChangeLocation4Players() {
		player.changeLocation(4);
		assertEquals(player.location, "West");
		player.changeLocation(4);
		assertEquals(player.location, "North");
		player.changeLocation(4);
		assertEquals(player.location, "East");
		player.changeLocation(4);
		assertEquals(player.location, "South");
	}

	@Test
	void testGetCardByName() {
		EasyMock.expect(family.get(0).getName()).andReturn("character1");

		EasyMock.replay(family.toArray());
		Card card = player.getCardByName("character1");

		EasyMock.verify(family.toArray());
		assertEquals(family.get(0), card);
	}
	
	@Test
	void testRemoveEventCard() {
		
	}


	@Test
	void testGetCardByNameNotThere() {
		for (Card card : family) {
			EasyMock.expect(card.getName()).andReturn("Some Random Name");
		}
		EasyMock.replay(family.toArray());
		try {
			player.getCardByName("Card that's not here");
			fail("Should have thrown a RuntimeException");
		} catch (RuntimeException e) {
			assertEquals("Does not have card", e.getMessage());
			EasyMock.verify(family.toArray());
		}
	}

	@Test
	void testUpdateCardPlayed() {
		Card played = EasyMock.createMock(Card.class);
		Card playedOn = EasyMock.createMock(Card.class);
		family.set(1, playedOn);
		playedOn.cleanUpOnCover(player);
		played.doImmediateSideEffect(player);
		EasyMock.expect(played.playCardOn(playedOn)).andReturn(played);

		EasyMock.replay(played, playedOn);
		player.updateCardPlayed(played, playedOn);

		EasyMock.verify(played, playedOn);
		assertEquals(played, family.get(1));
	}

	@Test
	void testUpdateCardPlayedFromHand() {
		Card played = hand.get(1);
		Card playedOn = EasyMock.createMock(Card.class);

		EasyMock.replay(playedOn);
		player.updateCardPlayed(played, playedOn);

		EasyMock.verify(playedOn);
		assertEquals(4, hand.size());
	}

	@Test
	void testGetCardInHandByTitle() {
		EasyMock.expect(hand.get(0).getTitle()).andReturn("DeathTitle1");

		EasyMock.replay(hand.toArray());
		Card card = player.getCardInHandByTitle("DeathTitle1");

		EasyMock.verify(hand.toArray());
		assertEquals(hand.get(0), card);
	}

	@Test
	void testGetCardInHandByTitleNotThere() {
		for (Card card : hand) {
			EasyMock.expect(card.getTitle()).andReturn("Some Random Title");
		}
		EasyMock.replay(hand.toArray());
		try {
			player.getCardInHandByTitle("Card that's not here");
			fail("Should have thrown a RuntimeException");
		} catch (RuntimeException e) {
			assertEquals("Invalid Card Selected", e.getMessage());
			EasyMock.verify(hand.toArray());
		}
	}

	@Test
	void testAddCardToHand() {
		Card played = hand.get(1);
		Card playedOn = EasyMock.createMock(Card.class);
		boolean failed = player.addToHand(played);

		EasyMock.replay(playedOn);
		player.updateCardPlayed(played, playedOn);

		boolean passed = player.addToHand(played);

		assertFalse(failed);
		assertTrue(passed);
		EasyMock.verify(playedOn);
	}

	@Test
	void testModifyTurn() {
		Turn turn = EasyMock.createMock(Turn.class);
		for (Card card : family) {
			EasyMock.expect(card.doSideEffectTurnChanges(turn)).andReturn(turn);
		}

		EasyMock.replay(family.toArray());
		EasyMock.replay(turn);
		Turn newTurn = player.modifyTurn(turn);

		EasyMock.verify(family.toArray());
		EasyMock.verify(turn);
		assertEquals(turn, newTurn);
	}

	@Test
	void testGetTurnNoChanges() {
		Turn turn = EasyMock.createMock(Turn.class);
		player.turn = turn;
		for (Card card : family) {
			EasyMock.expect(card.doSideEffectTurnChanges(turn)).andReturn(turn);
		}

		EasyMock.replay(family.toArray());
		Turn output = player.getTurn();

		assertEquals(turn, output);
		EasyMock.verify(family.toArray());
	}

	@Test
	void testGetTurnWithChange() {
		Turn originalTurn = EasyMock.createMock(Turn.class);
		Turn outerTurn = EasyMock.createMock(Turn.class);
		player.turn = originalTurn;
		for (int i = 0; i < family.size(); i++) {
			Card card = family.get(i);
			if (i == 0) {
				EasyMock.expect(card.doSideEffectTurnChanges(originalTurn)).andReturn(outerTurn);
			} else {
				EasyMock.expect(card.doSideEffectTurnChanges(outerTurn)).andReturn(outerTurn);
			}
		}

		EasyMock.replay(family.toArray());
		EasyMock.replay(originalTurn, outerTurn);
		Turn output = player.getTurn();

		assertEquals(outerTurn, output);
		EasyMock.verify(family.toArray());
		EasyMock.verify(originalTurn, outerTurn);
	}

	@Test
	void testDiscardHand() {
		player.discardHand();

		assertEquals(0, player.hand.size());
	}

	@Test
	void testIsFamilyDeadWithDeadFamily() {
		for (Card card : family) {
			EasyMock.expect(card.isAlive()).andReturn(false);
		}

		EasyMock.replay(family.toArray());
		boolean output = player.isFamilyDead();

		assertTrue(output);
		EasyMock.verify(family.toArray());
	}

	@Test
	void testIsFamilyDeadWithLivingFamily() {

		EasyMock.expect(family.get(0).isAlive()).andReturn(true);

		EasyMock.replay(family.toArray());
		boolean output = player.isFamilyDead();

		assertFalse(output);
		EasyMock.verify(family.toArray());
	}
	
	@Test
	void testChangeDrawLimit() {
		assertEquals(5, player.drawLimit);
		
		player.changeDrawLimit(1);
		
		assertEquals(6, player.drawLimit);
		
		player.changeDrawLimit(-1);
		
		assertEquals(5, player.drawLimit);
	}
	
	@Test
	void testForceAddToHand() {
		Card card = EasyMock.createMock(Card.class);
		int numCards = player.hand.size();
		
		EasyMock.replay(card);
		player.forceAddToHand(card);
		
		EasyMock.verify(card);
		assertEquals(numCards + 1, player.hand.size());
	}
	
	@Test
	void testDiscardCards() {
		int numCards = player.hand.size();
		
		player.discardCards(1);
		
		assertEquals(numCards - 1, player.hand.size());
	}
	
	@Test
	void testDiscardCardsEmptyHand() {
		this.hand = EasyMock.createMock(List.class);
		player.hand = this.hand;
		EasyMock.expect(hand.size()).andReturn(0);
		
		EasyMock.replay(hand);
		player.discardCards(1);
		
		EasyMock.verify(hand);
	}

	@Test
	void testGetTotalScoreDeadFamily() {
		int i = 0;
		for (Card card : family) {
			EasyMock.expect(card.isAlive()).andReturn(false);
			EasyMock.expect(card.getTotalPoints()).andReturn(5 + i);
			i += 1;
		}

		EasyMock.replay(family.toArray());
		int points = player.getTotalScore();
		assertEquals(35, points);
		EasyMock.verify(family.toArray());
	}
	
	@Test
	void testGetTotalScoreAliveFamily() {
		for (Card card : family) {
			EasyMock.expect(card.isAlive()).andReturn(true);
		}

		EasyMock.replay(family.toArray());
		int points = player.getTotalScore();
		assertEquals(0, points);
		EasyMock.verify(family.toArray());
	}
	
	@Test
	void testCompareTo() {
		Player player1 = EasyMock.partialMockBuilder(Player.class).addMockedMethod("getTotalScore").createMock();
		Player player2 = EasyMock.partialMockBuilder(Player.class).addMockedMethod("getTotalScore").createMock();
		EasyMock.expect(player1.getTotalScore()).andReturn(60);
		EasyMock.expect(player2.getTotalScore()).andReturn(-50);
	
		EasyMock.replay(player1);
		EasyMock.replay(player2);
		int compare = player1.compareTo(player2);
		
		assertEquals(-1, compare);
		EasyMock.verify(player1);
		EasyMock.verify(player2);
	}
	
	@Test
	void testCountNumberOfDuckIconsActive() {
		EasyMock.expect(family.get(0).getStoryIconString()).andReturn("Duck");
		EasyMock.expect(family.get(1).getStoryIconString()).andReturn("Duck");
		EasyMock.expect(family.get(2).getStoryIconString()).andReturn("Duck");
		EasyMock.expect(family.get(3).getStoryIconString()).andReturn("Duck");
		EasyMock.expect(family.get(4).getStoryIconString()).andReturn("Duck");
		
		EasyMock.replay(family.toArray());
		int output = player.countNumberOfDuckIconsActive();
		
		EasyMock.verify(family.toArray());
		assertEquals(5, output);
		
	}
	
	@Test
	void testCountNumberOfDuckIconsActiveNone() {
		EasyMock.expect(family.get(0).getStoryIconString()).andReturn("Something");
		EasyMock.expect(family.get(1).getStoryIconString()).andReturn("Something");
		EasyMock.expect(family.get(2).getStoryIconString()).andReturn("Something");
		EasyMock.expect(family.get(3).getStoryIconString()).andReturn("Something");
		EasyMock.expect(family.get(4).getStoryIconString()).andReturn("Something");
		
		EasyMock.replay(family.toArray());
		int output = player.countNumberOfDuckIconsActive();
		
		EasyMock.verify(family.toArray());
		assertEquals(0, output);
	}
	
	@Test 
	void testGetLocation() {
		String location = "South"; 
		String receivedLocation = player.getLocation(); 
		assertEquals(location, receivedLocation); 
	}
	

	@Test
	void testCompareToEqual() {
		Player player1 = EasyMock.partialMockBuilder(Player.class).addMockedMethod("getTotalScore").createMock();
		Player player2 = EasyMock.partialMockBuilder(Player.class).addMockedMethod("getTotalScore").createMock();
		EasyMock.expect(player1.getTotalScore()).andReturn(0);
		EasyMock.expect(player2.getTotalScore()).andReturn(0);
	
		EasyMock.replay(player1);
		EasyMock.replay(player2);
		int compare = player1.compareTo(player2);
		
		assertEquals(0, compare);
		EasyMock.verify(player1);
		EasyMock.verify(player2);
	}
	
	@Test
	void testCompareToOtherIsGreater() {
		Player player1 = EasyMock.partialMockBuilder(Player.class).addMockedMethod("getTotalScore").createMock();
		Player player2 = EasyMock.partialMockBuilder(Player.class).addMockedMethod("getTotalScore").createMock();
		EasyMock.expect(player1.getTotalScore()).andReturn(0);
		EasyMock.expect(player2.getTotalScore()).andReturn(10);
	
		EasyMock.replay(player1);
		EasyMock.replay(player2);
		int compare = player1.compareTo(player2);
		
		assertEquals(1, compare);
		EasyMock.verify(player1);
		EasyMock.verify(player2);
	}

}
