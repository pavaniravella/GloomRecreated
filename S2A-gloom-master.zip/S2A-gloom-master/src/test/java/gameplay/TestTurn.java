package gameplay;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.easymock.EasyMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import cards.Card;
import cards.UntimelyDeathCard;
import gameplay.Player;
import gameplay.Subject;
import gameplay.StandardTurn;
import gui.MainGameGUI;

class TestTurn {

	Player player;
	Player otherPlayer;
	MainGameGUI guiController;
	List<Player> players;
	Subject subject;
	StandardTurn turn;
	Card testCard;
	UntimelyDeathCard deathCard;
	Card testCardToPlayOn;

	@BeforeEach
	void setup() {
		player = EasyMock.createMock(Player.class);
		otherPlayer = EasyMock.createMock(Player.class);
		guiController = EasyMock.createMock(MainGameGUI.class);
		players = new ArrayList<Player>();
		players.add(player);
		players.add(otherPlayer);
		subject = EasyMock.createMock(Subject.class);
		turn = new StandardTurn(player, guiController, players, subject);
		testCard = EasyMock.createMock(Card.class);
		deathCard = EasyMock.createMock(UntimelyDeathCard.class);
		testCardToPlayOn = EasyMock.createMock(Card.class);
	}
	
	@Test
	void testGameOver() {
		EasyMock.expect(player.isFamilyDead()).andReturn(false);
		EasyMock.expect(otherPlayer.isFamilyDead()).andReturn(false);
		EasyMock.expect(player.isFamilyDead()).andReturn(true);
		
		EasyMock.replay(player);
		boolean notOver = turn.isGameOver();
		assertFalse(notOver);

		boolean over = turn.isGameOver();

		EasyMock.verify(player);
		assertTrue(over);
	}


	@Test
	void testDoFirstTurn() {
		testDoTurnNTimes(1);
		EasyMock.expect(testCard.canPlayOn(testCardToPlayOn, 1)).andReturn(true);
		
		EasyMock.replay(guiController, player, otherPlayer, testCard, testCardToPlayOn, subject);
		turn.doFirstTurn();
		
		EasyMock.verify(guiController, player, otherPlayer, testCard, testCardToPlayOn, subject);
	}
	
	@Test
	void testDoTurnSkipped() {
		guiController.createFrame();
		guiController.skippedTurn();
		player.displayFamily();
		otherPlayer.displayFamily();
		player.displayHand();
		EasyMock.expect(guiController.getCardToPlay()).andReturn("Skip Turn");
		
		EasyMock.replay(guiController, player, otherPlayer);
		guiController.skippedTurn();
		turn.doFirstTurn();
		
		EasyMock.verify(guiController, player, otherPlayer);
	}

	@Test
	void testDoFirstTurnCannotPlayFirstCardToPlayOn() {
		testDoTurnNTimes(2);
		EasyMock.expect(testCard.canPlayOn(testCardToPlayOn, 1)).andReturn(false).once();
		guiController.playedIncorrectCard("Cannot Play Card");
		EasyMock.expect(testCard.canPlayOn(testCardToPlayOn, 1)).andReturn(true).once();
		
		EasyMock.replay(guiController, player, otherPlayer, testCard, testCardToPlayOn, subject);
		turn.doFirstTurn();
		
		EasyMock.verify(guiController, player, otherPlayer, testCard, testCardToPlayOn, subject);
	}

	@Test
	void testDoFirstTurnCannotPlayFirstCardToPlay() {
		guiController.createFrame();
		player.displayFamily();
		otherPlayer.displayFamily();
		player.displayHand();
		EasyMock.expect(guiController.getCardToPlay()).andReturn("Test Card").times(1);
		EasyMock.expect(player.getCardInHandByTitle("Test Card")).andThrow(new RuntimeException());
		guiController.playedIncorrectCard("Cannot Play Card");

		testDoTurnNTimes(1);
		EasyMock.expect(testCard.canPlayOn(testCardToPlayOn, 1)).andReturn(true);

		EasyMock.replay(guiController, player, otherPlayer, testCard, testCardToPlayOn, subject);
		turn.doFirstTurn();
		
		EasyMock.verify(guiController, player, otherPlayer, testCard, testCardToPlayOn, subject);
	}

	@Test
	void testDoSecondTurn() {
		testDoTurnNTimes(1);
		EasyMock.expect(testCard.canPlayOn(testCardToPlayOn, 2)).andReturn(true);
		
		EasyMock.replay(guiController, player, otherPlayer, testCard, testCardToPlayOn, subject);
		turn.doSecondTurn();
		
		EasyMock.verify(guiController, player, otherPlayer, testCard, testCardToPlayOn, subject);
	}

	@Test
	void testDoDrawPhase() {
		List<Card> deck = new ArrayList<Card>();
		Card card1 = EasyMock.createMock(Card.class);
		Card card2 = EasyMock.createMock(Card.class);
		Card card3 = EasyMock.createMock(Card.class);
		deck.addAll(Arrays.asList(card1, card2, card3));
		
		EasyMock.expect(player.addToHand(card1)).andReturn(true);
		EasyMock.expect(player.addToHand(card2)).andReturn(true);
		EasyMock.expect(player.addToHand(card3)).andReturn(false);
		
		EasyMock.replay(card1, card2, card3, player);
		turn.doDrawPhase(deck);
		
		assertEquals(1, deck.size());
	}
	
	@Test
	void testCountNumberDuckIconsInPlay() {
		for(Player player: players) {
			EasyMock.expect(player.countNumberOfDuckIconsActive()).andReturn(1);
		}
		
		EasyMock.replay(players.toArray());
		int output = turn.countNumberDuckIconsInPlay();
		
		EasyMock.verify(players.toArray());
		assertEquals(2, output);
	}

	private void testDoTurnNTimes(int n) {
		guiController.createFrame();
		EasyMock.expectLastCall().times(2 * n);
		player.displayFamily();
		EasyMock.expectLastCall().times(2 * n);
		otherPlayer.displayFamily();
		EasyMock.expectLastCall().times(2 * n);
		player.displayHand();
		EasyMock.expectLastCall().times(n);
		EasyMock.expect(guiController.getCardToPlay()).andReturn("Test Card").times(n);
		EasyMock.expect(player.getCardInHandByTitle("Test Card")).andReturn(testCard).times(n);
		EasyMock.expect(guiController.getCardToPlayOn()).andReturn("Test Character Card").times(n);
		EasyMock.expect(player.getCardByName("Test Character Card"))
				.andThrow(new RuntimeException("Does not have card")).times(n);
		EasyMock.expect(otherPlayer.getCardByName("Test Character Card")).andReturn(testCardToPlayOn).times(n);
		subject.notifyCardPlayed(testCard, testCardToPlayOn);
	}

}
