package gameplay;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.easymock.EasyMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import cards.Card;
import cards.CharacterCard;
import cards.UntimelyDeathCard;
import data.CardAccessor;
import effects.DoNothingEffect;
import gui.MainGameGUI;
import gui.ScoresGUI;
import gui.StartScreenGUI;

class TestGameManager {
	
	MainGameGUI guiController;
	CardAccessor cardAccessor;
	GameManager manager;
	ScoresGUI scoresGUI;
	StartScreenGUI startGUI;
	
	@BeforeEach
	private void setup() {
		startGUI = EasyMock.createMock(StartScreenGUI.class);
		guiController = EasyMock.createMock(MainGameGUI.class);
		scoresGUI = EasyMock.createMock(ScoresGUI.class);
		cardAccessor = EasyMock.createMock(CardAccessor.class);
		List<Card> dummyCardList = getDummyCardList();
		List<Card> dummyCharacterList = getDummyCharacterList();
		EasyMock.expect(cardAccessor.getUntimelyDeathCards()).andReturn(dummyCardList);
		EasyMock.expect(cardAccessor.getCharacterCards()).andReturn(dummyCharacterList);
		EasyMock.expect(cardAccessor.getModifierCards()).andReturn(dummyCardList);
		EasyMock.replay(cardAccessor);
		manager = new GameManager(startGUI, guiController, scoresGUI);
	}
	
	@Test
	void testSetLocaleSetupGame() {
		EasyMock.expect(startGUI.displayStartScreen()).andReturn(new ArrayList<String>());
		EasyMock.expect(startGUI.getSelectedLocale()).andReturn(1);
		guiController.setLocale(1);
		
		EasyMock.replay(startGUI, guiController);
		manager.setupGame();
		
		EasyMock.verify(startGUI, guiController);
	}
	
	@Test
	void testDeckSize() {
		setExpectationsNPlayerGameSetup(2);
		
		EasyMock.replay(startGUI);
		manager.setupGame();
		int size = manager.getDeckSize();
		
		assertEquals(67, size);
		manager.createHand();

		int afterSize = manager.getDeckSize();
		assertEquals(62, afterSize); 
	}
	
	@Test
	void testRunGame() {
		String[] expectedNames = new String[] { "Alex" };
		int[] expectedPoints = new int[] { -20 };
		StandardTurn turn = EasyMock.createMock(StandardTurn.class);
		List<Player> players = new ArrayList<Player>();
		Player player = EasyMock.partialMockBuilder(Player.class).
				addMockedMethod("getPlayerName").
				addMockedMethod("getTotalScore").createMock();
		players.add(player);
		
		manager = EasyMock.partialMockBuilder(GameManager.class).
				addMockedMethod("doPlayerTurn").
				addMockedMethod("getTurn").
				addMockedMethod("changePlayerLocations").createMock();
		manager.doPlayerTurn(EasyMock.anyObject(Turn.class));
		EasyMock.expect(manager.getTurn(0)).andReturn(turn);
		EasyMock.expect(turn.isGameOver()).andReturn(false).once();
		turn.doDrawPhase(null);
		EasyMock.expect(manager.changePlayerLocations(players)).andReturn(players);
		EasyMock.expect(manager.getTurn(1)).andReturn(turn);
		EasyMock.expect(turn.isGameOver()).andReturn(true).once();
		EasyMock.expect(player.getPlayerName()).andReturn("Alex");
		EasyMock.expect(player.getTotalScore()).andReturn(-20);
		scoresGUI.displayScores(EasyMock.anyObject(), EasyMock.anyObject());
		guiController.endGame();
		manager.players = players;
		manager.guiController = guiController;
		manager.scoresGUI = scoresGUI;
		
		EasyMock.replay(turn, player, manager, guiController, scoresGUI);
		manager.runGame();
		
		EasyMock.verify(turn, player, manager, guiController, scoresGUI);
	}
	
	@Test
	void testCreateHand() {
		setExpectationsNPlayerGameSetup(2);
		
		EasyMock.replay(startGUI);
		manager.setupGame();
		List<Card> hand = manager.createHand();
		
		assertEquals(5, hand.size());
	}
	
	@Test
	void testDoPlayerTurn() {
		StandardTurn turn = EasyMock.createMock(StandardTurn.class);
		turn.doFirstTurn();
		EasyMock.expect(turn.isGameOver()).andReturn(false);
		turn.doSecondTurn();

		EasyMock.replay(turn);
		manager.doPlayerTurn(turn);
		
		EasyMock.verify(turn);
	}
	
	@Test
	void testDoPlayerTurnGameIsOver() {
		StandardTurn turn = EasyMock.createMock(StandardTurn.class);
		turn.doFirstTurn();
		EasyMock.expect(turn.isGameOver()).andReturn(true);

		EasyMock.replay(turn);
		manager.doPlayerTurn(turn);
		
		EasyMock.verify(turn);
	}

	@Test
	void testNumberOfPlayers2Players(){
		setExpectationsNPlayerGameSetup(2);

		EasyMock.replay(startGUI);
		manager.setupGame();
		
		int players = manager.getNumberOfPlayers();
		assertEquals(players, 2);
	}
	
	@Test
	void testNumberOfPlayers3Players(){
		setExpectationsNPlayerGameSetup(3);

		EasyMock.replay(startGUI);
		manager.setupGame();
		
		int players = manager.getNumberOfPlayers();
		assertEquals(players, 3);
	}
	
	@Test
	void testNumberOfPlayers4Players(){
		setExpectationsNPlayerGameSetup(4);

		EasyMock.replay(startGUI);
		manager.setupGame();
		
		int players = manager.getNumberOfPlayers();
		assertEquals(players, 4);
	}
	
	@Test
	void testGetTurn() {
		Player player = EasyMock.createMock(Player.class);
		List<Player> players = new ArrayList<Player>();
		players.add(player);
		manager.players = players;
		Turn turn = EasyMock.createMock(Turn.class);
		EasyMock.expect(player.modifyTurn(EasyMock.anyObject(Turn.class))).andReturn(turn);
		turn.doPreTurnOperations(manager.deck, players, player);
		
		EasyMock.replay(turn, player);
		Turn output = manager.getTurn(0);
		
		assertEquals(turn, output);
		EasyMock.verify(turn, player);
	}
	
	@Test
	void testGetTurnNotFirst() {
		Player player1 = EasyMock.createMock(Player.class);
		Player player2 = EasyMock.createMock(Player.class);
		Player player3 = EasyMock.createMock(Player.class);
		List<Player> players = new ArrayList<Player>();
		players.addAll(Arrays.asList(new Player[] {player1, player2, player3}));
		manager.players = players;
		Turn turn = EasyMock.createMock(Turn.class);
		EasyMock.expect(player2.modifyTurn(EasyMock.anyObject(Turn.class))).andReturn(turn);
		turn.doPreTurnOperations(manager.deck, players, player2);
		
		EasyMock.replay(turn, player1, player2, player3);
		Turn output = manager.getTurn(1);
		
		assertEquals(turn, output);
		EasyMock.verify(turn, player1, player2, player3);
	}
	
	@Test
	void testSwitchPlayerLocations() {
		Player player1 = EasyMock.createMock(Player.class);
		Player player2 = EasyMock.createMock(Player.class);
		player1.changeLocation(2);
		player2.changeLocation(2);

		EasyMock.replay(player1, player2);
		List<Player> beforeSwitchPlayers = new LinkedList<Player>(Arrays.asList(player1, player2));
		List<Player> updatedPlayers = manager.changePlayerLocations(beforeSwitchPlayers);
		
		EasyMock.verify(player1, player2);
		assertTrue(updatedPlayers.contains(player1));
		assertTrue(updatedPlayers.contains(player2));
	}
	
	@Test
	void testCreatePlayer() {
		String name = "Test";
		String placeOnScreen = "Location";
		manager = EasyMock.partialMockBuilder(GameManager.class)
				.addMockedMethod("registerObserver")
				.createMock();
		manager.registerObserver(EasyMock.anyObject(Player.class));
		List<Card> characterCards = EasyMock.createMock(List.class);
		EasyMock.expect(characterCards.remove(0)).andReturn(EasyMock.createMock(Card.class)).times(5);
		manager.characters = characterCards;
		List<Card> deck = EasyMock.createMock(List.class);
		EasyMock.expect(deck.remove(0)).andReturn(EasyMock.createMock(Card.class)).times(5);
		manager.deck = deck;
		
		EasyMock.replay(manager, characterCards, deck);
		Player output = manager.createPlayer(name, placeOnScreen);
		
		EasyMock.verify(manager, characterCards, deck);
		assertEquals(5, output.family.size());
	}
	
	@Test
	void testGetFinalScores() {
		manager = EasyMock.partialMockBuilder(GameManager.class).
				addMockedMethod("createPlayer").createMock();
		Player player1 = EasyMock.partialMockBuilder(Player.class).
				addMockedMethod("getTotalScore").createMock();
		Player player2 = EasyMock.partialMockBuilder(Player.class).
				addMockedMethod("getTotalScore").createMock();
		int[] expected = new int[] { -40, -20 };
		
		setExpectationsNPlayerGameSetup(2);
		EasyMock.expect(manager.createPlayer(EasyMock.anyString(), 
				EasyMock.anyString())).andReturn(player1);
		EasyMock.expect(manager.createPlayer(EasyMock.anyString(), 
				EasyMock.anyString())).andReturn(player2);
		EasyMock.expect(player1.getTotalScore()).andReturn(-20).times(2);
		EasyMock.expect(player2.getTotalScore()).andReturn(-40).times(2);
		
		EasyMock.replay(player1, player2, manager, startGUI);
		manager.setupGame();
		int[] orderedScores = manager.getFinalScores();
		
		for(int i = 0; i < orderedScores.length; i++) {
			assertEquals(expected[i], orderedScores[i]);
		}
		EasyMock.verify(player1,player2);
	}
	
	@Test
	void testGetFinalPlayerOrder() {
		manager = EasyMock.partialMockBuilder(GameManager.class).
				addMockedMethod("createPlayer").createMock();
		Player player1 = EasyMock.partialMockBuilder(Player.class).
				addMockedMethod("getPlayerName").
				addMockedMethod("getTotalScore").createMock();
		Player player2 = EasyMock.partialMockBuilder(Player.class).
				addMockedMethod("getPlayerName").
				addMockedMethod("getTotalScore").createMock();
		String[] expected = new String[] { "Alex", "Kim" };
		
		setExpectationsNPlayerGameSetup(2);
		EasyMock.expect(manager.createPlayer(EasyMock.anyString(), 
				EasyMock.anyString())).andReturn(player1);
		EasyMock.expect(manager.createPlayer(EasyMock.anyString(), 
				EasyMock.anyString())).andReturn(player2);
		EasyMock.expect(player1.getPlayerName()).andReturn("Kim");
		EasyMock.expect(player2.getPlayerName()).andReturn("Alex");
		EasyMock.expect(player1.getTotalScore()).andReturn(-20);
		EasyMock.expect(player2.getTotalScore()).andReturn(-40);
		
		EasyMock.replay(player1, player2, manager, startGUI);
		manager.setupGame();
		String[] orderedNames = manager.getFinalPlayerOrder();
		
		for(int i = 0; i < orderedNames.length; i++) {
			assertEquals(expected[i], orderedNames[i]);
		}
		EasyMock.verify(player1,player2);
	}
	
	@Test
	void testNotifyCardPlayed() {
		Card played = EasyMock.createMock(Card.class);
		Card playedOn = EasyMock.createMock(Card.class);
		List<Observer> observers = new LinkedList<Observer>();
		Observer mockObserver = EasyMock.createMock(Observer.class);
		observers.add(mockObserver);
		manager.observers = observers;
		mockObserver.updateCardPlayed(played, playedOn);
		
		EasyMock.replay(played, playedOn, mockObserver);
		manager.notifyCardPlayed(played, playedOn);
		
		EasyMock.verify(played, playedOn, mockObserver);
	}
	
	@Test
	void testDeregisterObserver() {
		List<Observer> observers = new LinkedList<Observer>();
		Observer mockObserver = EasyMock.createMock(Observer.class);
		observers.add(mockObserver);
		manager.observers = observers;
		
		EasyMock.replay(mockObserver);
		manager.deregisterObserver(mockObserver);
		
		EasyMock.verify(mockObserver);
		assertEquals(0, observers.size());
	}
	
	@Test
	void testShuffleDeck() {
		List<Card> deck = EasyMock.createMock(List.class);
		EasyMock.expect(deck.size()).andReturn(4);
		EasyMock.expect(deck.get(EasyMock.anyInt())).andReturn(EasyMock.createMock(Card.class)).anyTimes();
		EasyMock.expect(deck.set(EasyMock.anyInt(), EasyMock.anyObject(Card.class))).andReturn(EasyMock.createMock(Card.class)).anyTimes();
		
		EasyMock.replay(deck);
		manager.shuffleDeck(deck);
		
		EasyMock.verify(deck);
	}
	
	private List<Card> getDummyCardList(){
		List<Card> dummyCardList = new LinkedList<Card>();
		for(int i = 0; i < 20; i++) {
			dummyCardList.add(new UntimelyDeathCard(null, "Dummy Title", "Dummy Description", "Dummy EffectDescription", null, null, null, null, null, new DoNothingEffect()));
		}
		return dummyCardList;
	}
	
	private List<Card> getDummyCharacterList() {
		List<Card> dummyCharacterList = new LinkedList<Card>();
		for(int i = 0; i < 20; i++) {
			dummyCharacterList.add(new CharacterCard("Dummy Name", "Dummy Title", "Dummy Description", "Dummy EffectDescription", null, null, null, "Dummy Family", null, new DoNothingEffect()));
		}
		return dummyCharacterList;
	}
	
	private void setExpectationsNPlayerGameSetup(int numPlayers) {
		List<String> dummyPlayerList = new ArrayList<String>();
		for(int i = 0; i < numPlayers; i++) {
			dummyPlayerList.add("dummyName");
		}
		EasyMock.expect(startGUI.displayStartScreen()).andReturn(dummyPlayerList);
		EasyMock.expect(startGUI.getSelectedLocale()).andReturn(0);
		guiController.setLocale(0);
		manager.startGUI = startGUI;
		manager.guiController = guiController;
	}
	
}
