package gameplay;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.easymock.EasyMock;
import org.junit.jupiter.api.Test;

import cards.Card;
import gui.MainGameGUI;

class TestSkipDrawPhaseTurn {

	@Test
	void testDoDrawPhase() {
		Player player = EasyMock.createMock(Player.class);
		MainGameGUI guiController = EasyMock.createMock(MainGameGUI.class);
		List<Player> players = new ArrayList<Player>();
		players.add(player);
		Subject subject = EasyMock.createMock(Subject.class);
		Turn innerTurn = EasyMock.createMock(Turn.class);
		Turn turn = new SkipDrawPhaseTurn(innerTurn);
		List<Card> deck = new ArrayList<Card>();
		Card card1 = EasyMock.createMock(Card.class);
		Card card2 = EasyMock.createMock(Card.class);
		Card card3 = EasyMock.createMock(Card.class);
		deck.addAll(Arrays.asList(card1, card2, card3));
		
		EasyMock.expect(player.addToHand(card1)).andReturn(true);
		EasyMock.expect(player.addToHand(card2)).andReturn(true);
		EasyMock.expect(player.addToHand(card3)).andReturn(false);
		
		EasyMock.replay(card1, card2, card3, player, guiController, subject, innerTurn);
		turn.doDrawPhase(deck);
		
		assertEquals(3, deck.size());
	}
	
	@Test
	void testDoPreTurnOperations() {
		List<Card> deck = EasyMock.createMock(List.class);
		List<Player> players = EasyMock.createMock(List.class);
		Player player = EasyMock.createMock(Player.class);
		Turn innerTurn = EasyMock.createMock(Turn.class);
		Turn turn = new SkipDrawPhaseTurn(innerTurn);
		innerTurn.doPreTurnOperations(deck, players, player);
		
		EasyMock.replay(deck, players, player, innerTurn);
		turn.doPreTurnOperations(deck, players, player);
		
		EasyMock.verify(deck, players, player, innerTurn);
	}
	
}

