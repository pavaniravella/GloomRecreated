package data; 

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.List;

import org.easymock.EasyMock;
import org.json.simple.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import cards.Card;
import cards.CharacterCard;
import cards.EmptyInnerCard;
import cards.ModifierCard;
import cards.UntimelyDeathCard;
import effects.Effect;
import effects.EffectFactory;

class TestCardAccessor {
	
	EffectFactory effectFactory;
	
	@BeforeEach
	void setup() {
		effectFactory = EasyMock.createMock(EffectFactory.class);
	}

	@Test
	void testGetUntimelyDeathCards() {
		int numUntimelyDeathCards = 20;
		CardAccessor accessor = new CardAccessor("./src/cards/", effectFactory, 0);
		EasyMock.expect(effectFactory.getEffect(EasyMock.anyString())).andReturn(EasyMock.createMock(Effect.class)).times(numUntimelyDeathCards);
		
		EasyMock.replay(effectFactory);
		List<Card> untimelyDeathCards = accessor.getUntimelyDeathCards();
		
		assertEquals(numUntimelyDeathCards, untimelyDeathCards.size());
		assertTrue(untimelyDeathCards.get(0) instanceof UntimelyDeathCard);
		EasyMock.verify(effectFactory);
	}
	
	@Test
	void testGetUntimelyDeathCardsBadDirectory() {
		CardAccessor accessor = new CardAccessor("./src/cards/", effectFactory, 0);
		try {
			accessor.getUntimelyDeathCards();
			fail("Should not be able to read cards from ./bad/path");
		} catch(BadCardReadPathException e) {
			assertEquals("untimelydeathcards.json not found in directory", e.getMessage());
		}
	}
	
	@Test
	void testGetModiferCardsBadDirectory() {
		CardAccessor accessor = new CardAccessor("./src/cards/", effectFactory, 0);
		try {
			accessor.getModifierCards();
			fail("Should not be able to read cards from ./bad/path");
		} catch(BadCardReadPathException e) {
			assertEquals("modifiercards.json not found in directory", e.getMessage());
		}
	}
	
	@Test
	void testGetCharacterCards() {
		int numCharacterCards = 20;
		CardAccessor accessor = new CardAccessor("./src/cards/", effectFactory, 0);
		EasyMock.expect(effectFactory.getEffect(EasyMock.anyString())).andReturn(EasyMock.createMock(Effect.class)).times(numCharacterCards);
		
		EasyMock.replay(effectFactory);
		List<Card> characterCards = accessor.getCharacterCards();
		
		assertEquals(numCharacterCards, characterCards.size());
		assertTrue(characterCards.get(0) instanceof CharacterCard);
		EasyMock.verify(effectFactory);
	}
	
	@Test
	void testGetModifierCards() {
		int numModifierCards = 57;
		CardAccessor accessor = new CardAccessor("./src/cards/", effectFactory, 0);
		EasyMock.expect(effectFactory.getEffect(EasyMock.anyString())).andReturn(EasyMock.createMock(Effect.class)).times(numModifierCards);
		
		EasyMock.replay(effectFactory);
		List<Card> modifierCards = accessor.getModifierCards();
		
		assertEquals(numModifierCards, modifierCards.size());
		assertTrue(modifierCards.get(0) instanceof ModifierCard);
		EasyMock.verify(effectFactory);
	}
	
	@Test
	void testparseCardJSONObjectInvalidClassType() {
		CardAccessor accessor = new CardAccessor("./this/path/does/not/matter", effectFactory, 0);
		JSONObject jsonObject = EasyMock.createMock(JSONObject.class);
		EasyMock.expect(jsonObject.get("name")).andReturn(null);
		EasyMock.expect(jsonObject.get("title")).andReturn(null);
		EasyMock.expect(jsonObject.get("description")).andReturn(null);
		EasyMock.expect(jsonObject.get("effect")).andReturn(null);
		EasyMock.expect(jsonObject.get("points1")).andReturn(null);
		EasyMock.expect(jsonObject.get("points2")).andReturn(null);
		EasyMock.expect(jsonObject.get("points3")).andReturn(null);
		EasyMock.expect(jsonObject.get("family")).andReturn(null);
		EasyMock.expect(jsonObject.get("storyIcon")).andReturn(null);
		EasyMock.expect(jsonObject.get("effect")).andReturn(null);
		EasyMock.expect(effectFactory.getEffect("")).andReturn(EasyMock.createMock(Effect.class));
		
		EasyMock.replay(jsonObject, effectFactory);
		try {
			accessor.parseCardJSONObject(EmptyInnerCard.class, jsonObject);
			fail("Should have thrown an exception");
		} catch(RuntimeException e) {}
	}
	
	@Test
	void testParseJSONIntegerValue() {
		CardAccessor accessor = new CardAccessor("./src/cards/", effectFactory, 0);
		String attributeName = "points1";
		JSONObject jsonObject = new JSONObject();
		Long expected = (long) 4;
		jsonObject.put(attributeName, expected);
		
		Integer value = accessor.parseJSONIntegerValue(attributeName, jsonObject);
		
		assertEquals(4, value);
	}
	
	@Test
	void testParseJSONIntegerNullValue() {
		CardAccessor accessor = new CardAccessor("./src/cards/", effectFactory, 0);
		String attributeName = "points1";
		JSONObject jsonObject = EasyMock.createMock(JSONObject.class);
		EasyMock.expect(jsonObject.get(attributeName)).andReturn(null);
		
		Integer value = accessor.parseJSONIntegerValue(attributeName, jsonObject);
		
		assertNull(value);
	}
	
	@Test
	void testParseJSONEffect() {
		CardAccessor accessor = new CardAccessor("./src/cards/", effectFactory, 0);
		String attributeName = "effect";
		String effectName = "Effect Name";
		JSONObject jsonObject = EasyMock.createMock(JSONObject.class);
		EasyMock.expect(jsonObject.get(attributeName)).andReturn(effectName);
		Effect expected = EasyMock.createMock(Effect.class);
		EasyMock.expect(effectFactory.getEffect(effectName)).andReturn(expected);
		
		EasyMock.replay(effectFactory, jsonObject, expected);
		Effect output = accessor.parseJSONEffect(jsonObject);
		
		assertEquals(expected, output);
		EasyMock.verify(effectFactory, jsonObject, expected);
	}
	
	@Test
	void testReadFileOneBad() {
		CardAccessor accessor = new CardAccessor("./src/cards/", effectFactory, 0);
		EasyMock.expect(effectFactory.getEffect(EasyMock.anyString())).andReturn(EasyMock.createMock(Effect.class)).times(57);
		
		EasyMock.replay(effectFactory);
		List<Card> cards = accessor.readFile(ModifierCard.class, "asdf", "modifiercards.json");
		
		EasyMock.verify(effectFactory);
		assertEquals(57, cards.size());
	}
	
	@Test
	void testReadFileBothBad() {
		CardAccessor accessor = new CardAccessor("./src/cards/", effectFactory, 0);
		try {
			accessor.readFile(ModifierCard.class, "asdf", "jkl;");
			fail("Should have thrown an exception");
		} catch(BadCardReadPathException e) {
			assertEquals("jkl; not found in directory", e.getMessage());
		}
	}
}