package cards;

import effects.Effect;
import gameplay.Player;

public class UntimelyDeathCard extends Card {

	Card innerCard;
	String title;
	String description;
	String effectDescription;
	
	public UntimelyDeathCard(String name, String title, String description, String effectDescription, Integer points1, Integer points2, Integer points3, String family, String storyIcon, Effect effect) {
		this.innerCard = new EmptyInnerCard();
		this.title = title;
		this.description = description;
		this.effectDescription = effectDescription;
	}

	public UntimelyDeathCard(Card innerCard, String title, String description) {
		this.innerCard = innerCard;
		this.title = title;
		this.description = description;
	}

	@Override
	public String getName() {
		return innerCard.getName();
	}

	@Override
	public String getDescription() {
		return description;
	}

	@Override
	public String getTitle() {
		return title;
	}
	
	@Override
	public String getStoryIconString() {
		return innerCard.getStoryIconString();
	}

	@Override
	public String getType() {
		return "Untimely Death";
	}
	
	@Override
	public String getEffectDescription() {
		return effectDescription;
	}

	
	@Override
	public boolean isAlive() {
		return false;
	}

	@Override
	public void cleanUpOnCover(Player player) {}
	
	@Override
	public Integer getPoints1() {
		if(innerCard == null) {
			return 0;
		}
		return innerCard.getPoints1();
	}
	
	@Override
	public Integer getPoints2() {
		if(innerCard == null) {
			return 0;
		}
		return innerCard.getPoints2();
	}
	
	@Override
	public Integer getPoints3() {
		if(innerCard == null) {
			return 0;
		}
		return innerCard.getPoints3();
	}
	
	@Override
	public boolean canPlayOn(Card card2, int turnNumber) {
		if(card2.getTotalPoints() < 0 && card2.isAlive()) {
			return true;
		}
		return false;
	}
	
	@Override
	public Card playCardOn(Card card2) {
		if(card2.getTotalPoints() < 0 && card2.isAlive()) {
			innerCard = card2;
			return this;
		}
		throw new InvalidCardPlayException();
	}

}
