package cards;

import effects.Effect;
import gameplay.Player;

public class CharacterCard extends Card {
	
	String name;
	String title;
	String description;
	Integer points1;
	Integer points2;
	Integer points3;

	public CharacterCard(String name, String title, String description, String effectDescription, Integer points1, Integer points2, Integer points3, String family, String storyIcon, Effect effect) {
		this.name = name;
		this.title = title;
		this.description = description;
		this.points1 = points1;
		this.points2 = points2;
		this.points3 = points3;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public String getDescription() {
		return description;
	}

	@Override
	public String getTitle() {
		return title;
	}
	
	@Override
	public String getEffectDescription() {
		return null;
	}

	@Override
	public Integer getPoints1() {
		return points1 == null ? 0 : points1;
	}
	
	@Override
	public Integer getPoints2() {
		return points2 == null ? 0 : points2;
	}
	
	@Override
	public Integer getPoints3() {
		return points3 == null ? 0 : points3;
	}

	@Override
	public String getType() {
		return "Character";
	}

	@Override
	public void cleanUpOnCover(Player player) {}


}
