package cards;

import gameplay.Player;
import gameplay.Turn;

public abstract class Card {
	
	public Integer getPoints1() {
		return 0;
	}
	
	public Integer getPoints2() {
		return 0;
	}
	
	public Integer getPoints3() {
		return 0;
	}
	
	public boolean isAlive() {
		return true;
	}

	abstract public String getName();
	
	abstract public String getDescription();
	
	abstract public String getTitle();

	abstract public String getEffectDescription();
	
	public boolean canPlayOn(Card card2, int turnNumber) {
		return false;
	}

	public Card playCardOn(Card card2) {
		throw new InvalidCardPlayException();
	}

	public int getTotalPoints() {
		return getPoints1() + getPoints2() + getPoints3();
	}

	public String getStoryIconString() {
		return "Blank";
	}

	public Turn doSideEffectTurnChanges(Turn turn) {
		return turn;
	}
	
	public abstract String getType();

	public void cleanUpOnCover(Player player){};
	
	public void doImmediateSideEffect(Player player) {};
	
}
