package cards;


public class InvalidCardPlayException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;

	@Override
	public String getMessage() {
		return "Can't play character card on character card.";
	}

}
