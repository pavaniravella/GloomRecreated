package cards;

import effects.Effect;
import gameplay.Player;

public class ModifierCard extends Card {
	
	Card innerCard;
	String title;
	String description;
	String effectDescription;
	Integer points1;
	Integer points2;
	Integer points3;
	Effect effect;
	
	public ModifierCard(String name, String title, String description, String effectDescription, Integer points1, Integer points2, Integer points3, String family, String storyIcon, Effect effect) {
		this.innerCard = new EmptyInnerCard();
		this.title = title;
		this.description = description;
		this.effectDescription = effectDescription;
		this.points1 = points1;
		this.points2 = points2;
		this.points3 = points3;
		this.effect = effect;
	}
	
	@Override
	public Integer getPoints1() {
		return points1 == null ? innerCard.getPoints1() : points1;
	}
	
	@Override
	public Integer getPoints2() {
		return points2 == null ? innerCard.getPoints2() : points2;
	}
	
	@Override
	public Integer getPoints3() {
		return points3 == null ? innerCard.getPoints3() : points3;
	}

	@Override
	public String getName() {
		return innerCard.getName();
	}

	@Override
	public String getDescription() {
		return description;
	}

	@Override
	public String getTitle() {
		return title;
	}
	
	@Override
	public String getEffectDescription() {
		return effectDescription;
	}
	
	@Override
	public boolean canPlayOn(Card card2, int turnNumber) {
		return card2.isAlive();
	}

	@Override
	public String getType() {
		return "Modifier";
	}
	
	@Override
	public Card playCardOn(Card toPlayOn) {
		innerCard = toPlayOn;
		return this;
	}

	@Override
	public void cleanUpOnCover(Player player) {
		effect.endEffect(player);
	}
	
	@Override
	public void doImmediateSideEffect(Player player) {
		effect.doImmediateEffect(player);
	}

}