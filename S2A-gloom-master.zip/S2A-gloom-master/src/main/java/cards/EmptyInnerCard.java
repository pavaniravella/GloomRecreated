package cards;

public class EmptyInnerCard extends Card {

	@Override
	public String getName() {
		return "";
	}

	@Override
	public String getDescription() {
		return null;
	}

	@Override
	public String getTitle() {
		return null;
	}

	@Override
	public String getType() {
		return "Empty"; 
	}

	@Override
	public String getEffectDescription() {
		return null;
	}

	
}
