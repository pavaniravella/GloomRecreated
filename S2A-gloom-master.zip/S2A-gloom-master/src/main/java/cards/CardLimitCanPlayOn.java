package cards;

public class CardLimitCanPlayOn extends Card {
	
	String storyIcon;
	Card innerCard;
	
	public CardLimitCanPlayOn(String storyIcon, Card innerCard) {
		this.storyIcon = storyIcon;
		this.innerCard = innerCard;
	}
	
	@Override
	public Integer getPoints1() {
		return innerCard.getPoints1();
	}
	
	@Override
	public Integer getPoints2() {
		return innerCard.getPoints2();
	}
	
	@Override
	public Integer getPoints3() {
		return innerCard.getPoints3();
	}
	
	@Override
	public boolean isAlive() {
		return innerCard.isAlive();
	}

	@Override
	public String getName() {
		return innerCard.getName();
	}

	@Override
	public String getDescription() {
		return innerCard.getDescription();
	}

	@Override
	public String getTitle() {
		return innerCard.getTitle();
	}

	@Override
	public String getType() {
		return innerCard.getType();
	}
	
	@Override
	public String getStoryIconString() {
		return innerCard.getStoryIconString();
	}
	
	@Override
	public boolean canPlayOn(Card card2, int turnNumber) {
		return card2.getStoryIconString().contentEquals(storyIcon);
	}
	
	@Override
	public Card playCardOn(Card card2) {
		Card output = innerCard.playCardOn(card2);
		this.innerCard = output;
		return this;
	}

	@Override
	public String getEffectDescription() {
		return null;
	}

}
