package data;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import cards.Card;
import cards.CharacterCard;
import cards.ModifierCard;
import cards.UntimelyDeathCard;
import effects.Effect;
import effects.EffectFactory;

public class CardAccessor {

	String cardFileDirectory;
	EffectFactory effectFactory;
	int locale;
	HashMap<Integer, String> localeToFileExtension;

	public CardAccessor(String cardFileDirectory, EffectFactory effectFactory, int locale) {
		this.locale = locale;
		this.cardFileDirectory = cardFileDirectory;
		this.effectFactory = effectFactory;
		localeToFileExtension = new HashMap<Integer, String>() {{
			put(0, "");
			put(1, "_sp");
		}};
	}

	public List<Card> getUntimelyDeathCards() {
		String fileExtension = localeToFileExtension.get(locale);
		String fileName = "untimelydeathcards" + fileExtension + ".json";
		String defaultName = "untimelydeathcards.json";
		List<Card> untimelyDeathCards = readFile(UntimelyDeathCard.class, fileName, defaultName);
		return untimelyDeathCards;
	}

	public List<Card> getCharacterCards() {
		String fileExtension = localeToFileExtension.get(locale);
		String fileName = "charactercards" + fileExtension + ".json";
		String defaultName = "charactercards.json";
		List<Card> characterCards = readFile(CharacterCard.class, fileName, defaultName);
		return characterCards;
	}
	
	public List<Card> getModifierCards(){
		String fileExtension = localeToFileExtension.get(locale);
		String fileName = "modifiercards" + fileExtension + ".json";
		String defaultName = "modifiercards.json";
	    List<Card> modifierCards = readFile(ModifierCard.class, fileName, defaultName); 
	    return modifierCards; 
	}
	
	@SuppressWarnings("unchecked")
	<T extends Card> List<Card> readFile(Class<T> type, String filename, String defaultFileName){
		List<Card> cards = new LinkedList<Card>();
		String path = cardFileDirectory + filename;
		try {
			JSONParser parser = new JSONParser();
			FileReader reader = new FileReader(path);
			Object obj = parser.parse(reader);
			JSONArray cardsJSON = (JSONArray) obj;
			cardsJSON.forEach(o -> {
				Card newCard = parseCardJSONObject(type, (JSONObject) o);
				cards.add(newCard);
			});
			return cards;
		} catch(FileNotFoundException e) {
			path = cardFileDirectory + defaultFileName;
			try {
				JSONParser parser = new JSONParser();
				FileReader reader = new FileReader(path);
				Object obj = parser.parse(reader);
				JSONArray cardsJSON = (JSONArray) obj;
				cardsJSON.forEach(o -> {
					Card newCard = parseCardJSONObject(type, (JSONObject) o);
					cards.add(newCard);
				});
				return cards;
			} catch(Exception e2) {
				throw new BadCardReadPathException(defaultFileName);
			}
		} catch(Exception e2) {
			throw new BadCardReadPathException(filename);
		}
	}
	
	<T extends Card> Card parseCardJSONObject(Class<T> type, JSONObject jsonObject){
		String name = (String) jsonObject.get("name");
		String title = (String) jsonObject.get("title");
		String description = (String) jsonObject.get("description");
		String effectDescription = (String) jsonObject.get("effect");
		Integer points1 = parseJSONIntegerValue("points1", jsonObject);
		Integer points2 = parseJSONIntegerValue("points2", jsonObject);
		Integer points3 = parseJSONIntegerValue("points3", jsonObject);
		String family = (String) jsonObject.get("family");
		String storyIcon = (String) jsonObject.get("storyIcon");
		Effect effect = parseJSONEffect(jsonObject);
		try {
			Constructor<T> constructor = type.getConstructor(String.class, String.class, String.class, String.class, Integer.class, Integer.class, Integer.class, String.class, String.class, Effect.class);
			return constructor.newInstance(name, title, description, effectDescription, points1, points2, points3, family, storyIcon, effect);
		} catch(Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}
	
	Effect parseJSONEffect(JSONObject jsonObject) {
		String effectString = (String) jsonObject.get("effect");
		if(effectString == null) effectString = "";
		return effectFactory.getEffect(effectString);
	}

	Integer parseJSONIntegerValue(String attributeName, JSONObject jsonObject) {
		Long longPoints = (Long) jsonObject.get(attributeName);
		return longPoints == null ? null : longPoints.intValue();
	}

}

