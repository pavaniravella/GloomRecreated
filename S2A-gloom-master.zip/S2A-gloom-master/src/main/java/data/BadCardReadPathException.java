package data;

public class BadCardReadPathException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	private String filename;
	
	public BadCardReadPathException(String filename) {
		this.filename = filename;
	}

	@Override
	public String getMessage() {
		return filename + " not found in directory";
	}
}
