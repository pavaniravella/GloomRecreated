package gui; 

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class HandButtonListener implements ActionListener {
	
	private String name;
	private String description;
	private String title;
	private MainGameGUI gui;
	private String points1;
	private String points2;
	private String points3;
	private String effectDescription;

	public HandButtonListener(MainGameGUI gui, String name, String description, String title,
								String points1, String points2, String points3, String effectDescription) {
		this.gui = gui;
		this.name = name;
		this.description = description;
		this.title = title;
		this.points1 = points1;
		this.points2 = points2;
		this.points3 = points3;
		this.effectDescription = effectDescription;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		gui.displayCard(name, description, title, points1, points2, points3, effectDescription);
	}
	
}
