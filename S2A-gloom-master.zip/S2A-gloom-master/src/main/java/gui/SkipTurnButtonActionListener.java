package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SkipTurnButtonActionListener implements ActionListener {

	private MainGameGUI guiController;

	public SkipTurnButtonActionListener(MainGameGUI guiController) {
		this.guiController = guiController;
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		guiController.cleanFrame();
		guiController.skippedTurn();
		guiController.setInputProvided(true);
	}

}
