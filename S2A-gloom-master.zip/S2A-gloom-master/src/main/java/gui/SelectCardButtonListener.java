package gui;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SelectCardButtonListener implements ActionListener {
	
	private MainGameGUI guiController;

	public SelectCardButtonListener(MainGameGUI guiController) {
		this.guiController = guiController;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		guiController.cleanFrame();
		guiController.setInputProvided(true);
	}
}
