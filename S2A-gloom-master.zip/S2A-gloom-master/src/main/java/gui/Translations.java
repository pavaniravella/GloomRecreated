package gui;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;

public class Translations {
	
	public static int ENGLISH_US = 0;
	private static String defaultName = "TranslationStrings.properties";
	private static HashMap<Integer, String> localetoFileExtension = new HashMap<Integer, String>() {{
		put(0, "");
		put(1, "_sp");
	}};
	
	public static String getString(String toTranslate, int locale) {
		String fileExtension = localetoFileExtension.get(locale);
		String fileName = "TranslationStrings" + fileExtension + ".properties";
		FileReader reader = null;
		try {
			reader = new FileReader(fileName);  
		} catch (FileNotFoundException e) {
			try {
				reader = new FileReader(defaultName);
			} catch (FileNotFoundException e2) {
				return "";
			}
		}
	    Properties p = new Properties();  
		try {
			p.load(reader);
			return p.getProperty(toTranslate);
		} catch (IOException exception) { 
			return "";
		}
	}

}
