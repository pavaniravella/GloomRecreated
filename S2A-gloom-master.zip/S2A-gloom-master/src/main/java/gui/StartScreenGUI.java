package gui;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class StartScreenGUI {
	
	private JPanel panel;
	private JFrame frame;
	private boolean inputProvided;
	private List<String> playerNames;
	private List<JTextField> textboxes;
	private JComboBox numberOfPlayersBox;
	private int locale;
	private JComboBox languageBox;
	
	private void createFrame() {
		this.frame = new JFrame();
		this.panel = new JPanel(new GridBagLayout());
		int defaultVal = GridBagConstraints.RELATIVE;
		this.inputProvided = false;
		this.playerNames = new ArrayList<String>();
		this.textboxes = new ArrayList<JTextField>();
		this.locale = Translations.ENGLISH_US;
		
		JLabel numlabel = new JLabel(Translations.getString("numPlayers", this.locale));
		numlabel.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		GridBagConstraints numConstraints = setFeatureLayout(defaultVal, 0.4, 0, 0, defaultVal, 1);
		panel.add(numlabel, numConstraints);
		
		String[] numPlayersoptions = new String[] { "2", "3", "4" };
		numberOfPlayersBox = new JComboBox();
		for(int i = 0; i < numPlayersoptions.length; i++) {
			numberOfPlayersBox.addItem(numPlayersoptions[i]);	
		}
		numberOfPlayersBox.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		GridBagConstraints pConstraints = setFeatureLayout(defaultVal, 0.45, 1, 0, defaultVal, 1);
		panel.add(numberOfPlayersBox, pConstraints);
		
		String[] languageOptions = new String[] { "English", "Spanish" };
		languageBox = new JComboBox();
		for(int i = 0; i < languageOptions.length; i++) {
			languageBox.addItem(languageOptions[i]);	
		}
		languageBox.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		GridBagConstraints lConstraints = setFeatureLayout(defaultVal, 0.45, 1, 1, defaultVal, 1);
		panel.add(languageBox, lConstraints);
		
		JLabel langLabel = new JLabel(Translations.getString("selectLanguage", this.locale));
		langLabel.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		GridBagConstraints langConstraints = setFeatureLayout(defaultVal, 0.4, 0, 1, defaultVal, 1);
		panel.add(langLabel, langConstraints);
		
		JLabel pLabel = new JLabel(Translations.getString("enterPlayers", this.locale));
		pLabel.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		GridBagConstraints enterNameConstraints = setFeatureLayout(defaultVal, 0.01, 0, 2, defaultVal, 1);
		panel.add(pLabel, enterNameConstraints);
		
		for(int i = 0; i < 4; i++) {
			createAndAddNameBox(i+2);
		}
		
		JButton startButton = new JButton(Translations.getString("startGame", this.locale));
		startButton.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		startButton.addActionListener(new StartButtonActionListener(this));
		GridBagConstraints startConstraints = setFeatureLayout(defaultVal, 0.45, 0, 6, defaultVal, 2);
		panel.add(startButton, startConstraints);
		
		frame.add(panel);
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		frame.setPreferredSize(screenSize);
		frame.pack();
		frame.setVisible(true);
		this.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public List<String> displayStartScreen() {
		createFrame();
		spinWaitForInput();
		List<String> playerNames = new ArrayList<String>();
		String comboBoxSelection = numberOfPlayersBox.getSelectedItem().toString();
		int numOfPlayers = Integer.parseInt(comboBoxSelection);
		for(int i = 0; i < numOfPlayers; i++) {
			playerNames.add(textboxes.get(i).getText());
		}
		frame.dispose();
		return playerNames;
	}
	
	public int getSelectedLocale() {
		return languageBox.getSelectedIndex();
	}
	
	private GridBagConstraints setFeatureLayout(double weightx, double weighty, int gridx, int gridy, int anchor, int gridWidth) {
		GridBagConstraints constraints = new GridBagConstraints();
		constraints.weightx = weightx;
		constraints.weighty = weighty;
		constraints.gridx = gridx;
		constraints.gridy = gridy;
		constraints.gridwidth = gridWidth;

		return constraints;
	}
	
	private void createAndAddNameBox(int yVal) {
		int defaultVal = GridBagConstraints.RELATIVE;
		JTextField nameBox = new JTextField("", 20);
		nameBox.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		GridBagConstraints nameConstraints = setFeatureLayout(defaultVal, 0.01, 1, yVal, defaultVal, 1);
		panel.add(nameBox, nameConstraints);
		textboxes.add(nameBox);
	}
	
	private void spinWaitForInput() {
		while (!inputProvided) {
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
			}
		}
	}
	
	public void setInputProvided(boolean inputProvided) {
		this.inputProvided = inputProvided;
	}
}

