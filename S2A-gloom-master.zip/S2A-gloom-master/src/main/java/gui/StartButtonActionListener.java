package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class StartButtonActionListener implements ActionListener {
	
	private StartScreenGUI startGUI;
	
	public StartButtonActionListener(StartScreenGUI startGUI) {
		this.startGUI = startGUI;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		this.startGUI.setInputProvided(true);
	}

}
