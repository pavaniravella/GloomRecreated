package gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class MainGameGUI {

	public JFrame frame;
	private JPanel mainPanel;
	private JPanel currentDisplayCardPanel;
	private String currentDisplayedCard;
	private boolean inputProvided;
	private String selectOrPlay;
	private int locale;

	public MainGameGUI() {
		currentDisplayedCard = "";
		this.frame = new JFrame();
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		screenSize.height = screenSize.height - 30;
		this.frame.setPreferredSize(screenSize);
		this.frame.setVisible(true);
		this.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.locale = Translations.ENGLISH_US;
	}

	public void createFrame() {
		this.mainPanel = new JPanel(new GridBagLayout());
		this.currentDisplayCardPanel = new JPanel();
		currentDisplayedCard = "";
		frame.pack();
		frame.add(mainPanel);
		setInputProvided(false);
	}
	
	public void cleanFrame() {
		frame.remove(this.mainPanel);
		frame.pack();
	}
	
	public void setLocale(int locale) {
		this.locale = locale;
	}

	public void displayHand(String[] names, String[] descriptions, String[] titles, 
								String[] points1, String[] points2, String[] points3, String[] effectDescriptions) {
		displayMultipleCards(24, GridBagConstraints.CENTER, 1, 4, titles, descriptions, names, points1, points2, points3, effectDescriptions);
	}

	public void displayMultipleCards(int fontSize, int constraintLayout, int gridXNumber,  int gridYNumber, String[] names,
			String[] descriptions, String[] titles, String[] points1, String[] points2, String points3[], String[] effectDescriptions) {
		JPanel handButtonPanel = new JPanel(new GridBagLayout());
		int defaultValue = GridBagConstraints.RELATIVE;
		GridBagConstraints handConstraint = new GridBagConstraints();
		if(constraintLayout == GridBagConstraints.EAST || constraintLayout == GridBagConstraints.WEST) {
			handConstraint = setFeatureLayout(0.2, 0.1, gridXNumber, gridYNumber,
					constraintLayout);
		} else {
			handConstraint = setFeatureLayout(0.4, 0.1, gridXNumber, gridYNumber,
					constraintLayout);
		}

		JButton[] hand = new JButton[names.length];
		for (int i = 0; i < names.length; i++) {
			hand[i] = new JButton(names[i]);
			hand[i].addActionListener(new HandButtonListener(this, names[i], descriptions[i], titles[i], 
					points1[i], points2[i], points3[i], effectDescriptions[i]));
			hand[i].setFont(new Font("Times New Roman", Font.PLAIN, fontSize));
			GridBagConstraints buttonConstraint = new GridBagConstraints();
			if(constraintLayout == GridBagConstraints.EAST || constraintLayout == GridBagConstraints.WEST) {
				buttonConstraint = setFeatureLayout(defaultValue, defaultValue, defaultValue, i,
						constraintLayout);
			} else {
				buttonConstraint = setFeatureLayout(defaultValue, defaultValue, i, defaultValue,
						constraintLayout);
			}
			handButtonPanel.add(hand[i], buttonConstraint);
		}
		mainPanel.add(handButtonPanel, handConstraint);
		frame.pack();
		frame.repaint();
	}

	public void displayFamilyCards(String location, String[] names, String[] descriptions, String[] titles,
			String[] points1, String[] points2, String points3[]) {
		int constraintLayout = 0;
		int gridYNumber = 0;
		int gridXNumber = 1;
		String[] effectDescriptions = new String[5];
		switch (location) {
		case "South":
			constraintLayout = GridBagConstraints.SOUTH;
			gridYNumber = 5;
			gridXNumber = 1;
			break;
		case "North":
			constraintLayout = GridBagConstraints.NORTH;
			gridYNumber = 0;
			gridXNumber = 1;
			break;
		case "East":
			constraintLayout = GridBagConstraints.EAST;
			gridYNumber = 2;
			gridXNumber = 2;
			break;
		case "West":
			constraintLayout = GridBagConstraints.WEST;
			gridYNumber = 2;
			gridXNumber = 0;
			break;
		default:
			break;
		}
		displayMultipleCards(18, constraintLayout, gridXNumber, gridYNumber, names, descriptions, titles, points1, points2, points3, effectDescriptions);
	}

	public void displayCard(String name, String description, String title, 
								String points1, String points2, String points3, String effectDescription) {
		this.mainPanel.remove(this.currentDisplayCardPanel);
		JPanel cardPanel = new JPanel(new GridBagLayout());
		int defaultValue = GridBagConstraints.RELATIVE;
		currentDisplayedCard = name;

		GridBagConstraints cardCon = setFeatureLayout(defaultValue, 0.4, 1, 2, defaultValue);

		GridBagConstraints nameCon = setFeatureLayout(defaultValue, defaultValue, defaultValue, 0, defaultValue);
		createAndAddJLabel(cardPanel, name, 42, nameCon);

		GridBagConstraints descCon = setFeatureLayout(defaultValue, defaultValue, defaultValue, 2, defaultValue);
		description = String.format("<html><div WIDTH=%d>%s</div></html>", 400, description);
		createAndAddJLabel(cardPanel, description, 20, descCon);

		GridBagConstraints titleCon = setFeatureLayout(defaultValue, defaultValue, defaultValue, 1, defaultValue);
		createAndAddJLabel(cardPanel, title, 36, titleCon);

		GridBagConstraints pointsCon = setFeatureLayout(defaultValue, defaultValue, defaultValue, 3, defaultValue);
		String pointsString = points1 + ", " + points2 + ", " + points3;
		createAndAddJLabel(cardPanel, pointsString, 36, pointsCon);
		
		GridBagConstraints effectCon = setFeatureLayout(defaultValue, defaultValue, defaultValue, 4, defaultValue);
		createAndAddJLabel(cardPanel, effectDescription, 20, effectCon);

		cardPanel.setPreferredSize(new Dimension(500, 500));
		cardPanel.setBorder(BorderFactory.createLineBorder(Color.black));
		mainPanel.add(cardPanel, cardCon);
		this.currentDisplayCardPanel = cardPanel;
		
		if(this.selectOrPlay.equals("Play")) {
			displayPlaySelectCardButton(Translations.getString("play", locale));
			this.selectOrPlay = "Done";
		} else if(this.selectOrPlay.equals("Select")) {
			displayPlaySelectCardButton(Translations.getString("select", locale));
			this.selectOrPlay = "Done";
		}

		frame.pack();
		frame.repaint();
	}
	
	private void displaySkipTurnButton() {
		int defaultValue = GridBagConstraints.RELATIVE;
		GridBagConstraints playCon = setFeatureLayout(defaultValue, defaultValue, 1, 1,
				GridBagConstraints.NORTH);
		JButton playButton = new JButton(Translations.getString("skipTurn", locale));
		playButton.addActionListener(new SkipTurnButtonActionListener(this));
		playButton.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		mainPanel.add(playButton, playCon);
		frame.pack();
	}

	private void displayPlaySelectCardButton(String text) {
		int defaultValue = GridBagConstraints.RELATIVE;
		GridBagConstraints playCon = setFeatureLayout(defaultValue, defaultValue, 1, 3,
				GridBagConstraints.NORTH);
		JButton playButton = new JButton(text);
		playButton.addActionListener(new SelectCardButtonListener(this));
		playButton.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		mainPanel.add(playButton, playCon);
	}

	private GridBagConstraints setFeatureLayout(double weightx, double weighty, int gridx, int gridy, int anchor) {
		GridBagConstraints constraints = new GridBagConstraints();
		constraints.weightx = weightx;
		constraints.weighty = weighty;
		constraints.gridx = gridx;
		constraints.gridy = gridy;

		return constraints;
	}

	public void createAndAddJLabel(JPanel panel, String text, int size, GridBagConstraints constraints) {
		JLabel label = new JLabel(text);
		label.setFont(new Font("Times New Roman", Font.PLAIN, size));
		panel.add(label, constraints);
	}

	public void playedIncorrectCard(String infoMessage) {
		JOptionPane.showMessageDialog(new JPanel(), infoMessage);
	}

	public String getCardToPlay() {
		setInputProvided(false);
		displaySkipTurnButton();
		this.selectOrPlay = "Play";
		spinWaitForInput();
		return currentDisplayedCard;
	}

	public String getCardToPlayOn() {
		setInputProvided(false);
		this.selectOrPlay = "Select";
		spinWaitForInput();
		return currentDisplayedCard;
	}

	private void spinWaitForInput() {
		while (!inputProvided) {
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
			}
		}
	}

	public void setInputProvided(boolean inputProvided) {
		this.inputProvided = inputProvided;
	}
	
	public void skippedTurn() {
		this.currentDisplayedCard = "Skip Turn";
	}
	
	public void endGame() {
		this.frame.dispose();
	}
}