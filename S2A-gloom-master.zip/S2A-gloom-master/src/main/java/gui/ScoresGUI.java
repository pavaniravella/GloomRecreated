package gui;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

public class ScoresGUI {
	
	public void displayScores(String[] names, int[] scores) {
		JPanel panel = new JPanel(new GridBagLayout());
		JFrame frame = new JFrame();
		Dimension screenSize = new Dimension(1000, 500);
		frame.setPreferredSize(screenSize);
		
		for(int i = 0; i < names.length; i++) {
			GridBagConstraints constraint = setFeatureLayout(0, 0, 0, i, 0);
			JLabel label = new JLabel(names[i] + ": " + scores[i]);
			label.setFont(new Font("Times New Roman", Font.PLAIN, 36));
			panel.add(label, constraint);
		}
		
		frame.pack();
		frame.setVisible(true);
		frame.add(panel);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	private GridBagConstraints setFeatureLayout(double weightx, double weighty, int gridx, int gridy, int anchor) {
		GridBagConstraints constraints = new GridBagConstraints();
		constraints.weightx = weightx;
		constraints.weighty = weighty;
		constraints.gridx = gridx;
		constraints.gridy = gridy;

		return constraints;
	}

}
