
package gameplay;

import java.util.List;

import cards.Card;

import gui.MainGameGUI;

public abstract class Turn {
	
	Player player;
	MainGameGUI guiController;
	List<Player> players;
	Subject subject;
	boolean isSkipped;
	
	public Turn(Player player, MainGameGUI guiController, List<Player> players, Subject subject) {
		this.player = player;
		this.guiController = guiController;
		this.players = players;
		this.subject = subject;
		this.isSkipped = false;
	}

	public void doFirstTurn() {
		doTurn(1);
	}

	public void doSecondTurn() {
		doTurn(2);
	}
	
	void doDrawPhase(List<Card> deck) {
		for(Player player : players) {
			Card topOfDeckCard = deck.remove(0);
			while(player.addToHand(topOfDeckCard)) {
				topOfDeckCard = deck.remove(0);
			}
			deck.add(0, topOfDeckCard);
		}
	}
	
	protected void doTurn(int turnNumber) {
		try {
			Card cardToPlay = getCardToPlay();
			if(isSkipped) {
				return;
			}
			Card cardToPlayOn = getCardToPlayOn();
			boolean canPlay = cardToPlay.canPlayOn(cardToPlayOn, turnNumber);
			if(canPlay) {
				subject.notifyCardPlayed(cardToPlay, cardToPlayOn);
			} else {
				guiController.playedIncorrectCard("Cannot Play Card");
				doTurn(turnNumber);
			}
		} catch (RuntimeException e) {
			guiController.playedIncorrectCard("Cannot Play Card");
			doTurn(turnNumber);
		}
	}

	private Card getCardToPlayOn() {
		displayFamilies();
		String cardToPlayOnName = guiController.getCardToPlayOn();
		Card cardToPlayOn = null;
		for(Player player: players) {
			try {
				cardToPlayOn = player.getCardByName(cardToPlayOnName);
			} catch(RuntimeException e) {}
		}
		return cardToPlayOn;
	}

	private Card getCardToPlay() {
		Card cardToPlay = null;
		displayFamilies();
		player.displayHand();
		String cardName = guiController.getCardToPlay();
		if(cardName.equals("Skip Turn")) {
			this.isSkipped = true;
		} else {
			cardToPlay = player.getCardInHandByTitle(cardName);
		}
		return cardToPlay;
		
	}
	
	
	private void displayFamilies() {
		guiController.createFrame();
		for(Player player : players) {
			player.displayFamily();
		}
	}
	
	public boolean isGameOver() {
		for (int i = 0; i < players.size(); i++) {
			if (players.get(i).isFamilyDead()) {
				return true;
			}
		}
		return false;
	}
	
	

	public abstract void doPreTurnOperations(List<Card> deck, List<Player> players, Player player);

	public int countNumberDuckIconsInPlay() {
		int count = 0;
		for(Player player : players) {
			count += player.countNumberOfDuckIconsActive();
		}
		return count;
	}

}


