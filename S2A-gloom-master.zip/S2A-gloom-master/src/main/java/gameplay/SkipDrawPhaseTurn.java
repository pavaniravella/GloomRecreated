package gameplay;

import java.util.List;

import cards.Card;

public class SkipDrawPhaseTurn extends Turn {
	
	Turn innerTurn;
	
	public SkipDrawPhaseTurn(Turn innerTurn) {
		super(innerTurn.player, innerTurn.guiController, innerTurn.players, innerTurn.subject);
		this.innerTurn = innerTurn;
	}
	
	@Override
	void doDrawPhase(List<Card> deck) {}

	@Override
	public void doPreTurnOperations(List<Card> deck, List<Player> players, Player player) {
		innerTurn.doPreTurnOperations(deck, players, player);
	}

}
