package gameplay;

import java.util.List;

import cards.Card;
import gui.MainGameGUI;

public class StandardTurn extends Turn {
	
	public StandardTurn(Player player, MainGameGUI guiController, List<Player> players, Subject subject) {
		super(player, guiController, players, subject);
	}

	@Override
	public void doPreTurnOperations(List<Card> deck, List<Player> players, Player player) {
		// TODO Auto-generated method stub
		
	}

}