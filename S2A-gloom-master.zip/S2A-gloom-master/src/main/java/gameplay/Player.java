package gameplay;

import java.util.Iterator;
import java.util.List;

import cards.Card;
import gui.MainGameGUI;


public class Player implements Observer, Comparable {

	MainGameGUI guiController;
	List<Card> hand;
	List<Card> family;
	String location;
	int drawLimit = 5;
	Turn turn;
	String playerName;
	boolean canPlayEventCard = true; 
	
	/*
	 * for the location we are going to have four directions: north, south, east, and west 
	 * left cases: 
	 * north = west
	 * west = south 
	 * south = east
	 * east = north 
	 * 
	 * right cases
	 * north = east 
	 * east = south 
	 * south = west 
	 * west = north 
	 */

	public Player(String playerName, List<Card> family, List<Card> hand, MainGameGUI gui, String location) {
		this.guiController = gui;
		this.hand = hand;
		this.family = family;
		this.location = location;
		this.playerName = playerName;
	}

	public String getPlayerName() {
		return playerName;
	}

	private String[] getNames(List<Card> toParse) {
		String[] names = new String[toParse.size()];
		int i = 0;
		for (Card card : toParse) {
			names[i] = card.getName();
			i++;
		}
		return names;
	}

	private String[] getTitles(List<Card> toParse) {
		String[] titles = new String[toParse.size()];
		int i = 0;
		for (Card card : toParse) {
			titles[i] = card.getTitle();
			i++;
		}
		return titles;
	}

	private String[] getDescriptions(List<Card> toParse) {
		String[] descriptions = new String[toParse.size()];
		int i = 0;
		for (Card card : toParse) {
			descriptions[i] = card.getDescription();
			i++;
		}
		return descriptions;
	}
	
	public String getLocation() {
		return this.location; 
	}


	public String[] getPoints(List<Card> toParse, int pointsNumber) {
		String[] points = new String[toParse.size()];
		int i = 0;
		for (Card card : toParse) {
			switch(pointsNumber) {
				case 1:
					points[i] = "" + card.getPoints1();
					break;
				case 2:
					points[i] = "" + card.getPoints2();
					break;
				case 3:
					points[i] = "" + card.getPoints3();
					break;
			}
			i++;
		}
		return points;
	}

	private String[] getEffectDescriptions(List<Card> toParse) {
		String[] effectDescriptions = new String[toParse.size()];
		int i = 0;
		for (Card card : toParse) {
			effectDescriptions[i] = card.getEffectDescription();
			i++;
		}
		return effectDescriptions;
	}

	public boolean isFamilyDead() {
		boolean isDead = true;
		for (int i = 0; i < family.size(); i++) {
			if (family.get(i).isAlive() == true) {
				isDead = false;
				break;
			}
		}
		return isDead;
	}

	public void displayHand() {
		String[] names = getNames(hand);
		String[] titles = getTitles(hand);
		String[] descriptions = getDescriptions(hand);
		String[] effectDescriptions = getEffectDescriptions(hand);
		String[] points1 = getPoints(hand, 1);
		String[] points2 = getPoints(hand, 2);
		String[] points3 = getPoints(hand, 3);
		guiController.displayHand(names, descriptions, titles, points1, points2, points3, effectDescriptions);
	}

	public void displayFamily() {
		String[] names = getNames(family);
		String[] titles = getTitles(family);
		String[] descriptions = getDescriptions(family);
		String[] points1 = getPoints(family, 1);
		String[] points2 = getPoints(family, 2);
		String[] points3 = getPoints(family, 3);
		guiController.displayFamilyCards(location, names, descriptions, titles, points1, points2, points3);
	}

	public Card getCardByName(String cardToPlayOnName) {
		for (Card card : family) {
			if (cardToPlayOnName.contentEquals(card.getName())) {
				return card;
			}
		}
		throw new RuntimeException("Does not have card");
	}

	@Override
	public void updateCardPlayed(Card played, Card playedOn) {
		for (int i = 0; i < family.size(); i++) {
			Card card = family.get(i);
			if (card == playedOn) {
				playedOn.cleanUpOnCover(this);
				played.doImmediateSideEffect(this);
				Card newCard = played.playCardOn(playedOn);
				family.set(i, newCard);
			}
		}
		Iterator<Card> iterator = hand.iterator();
		while (iterator.hasNext()) {
			Card card = iterator.next();
			if (card == played) {
				iterator.remove();
			}
		}
	}

	public Card getCardInHandByTitle(String cardTitle) {
		for (Card card : hand) {
			if (cardTitle.contentEquals(card.getTitle())) {
				return card;
			}
		}
		throw new RuntimeException("Invalid Card Selected");
	}

	public boolean addToHand(Card card) {
		if(this.hand.size() >= drawLimit) {
			return false;
		}
		this.hand.add(card);
		return true;
	}

	public Turn modifyTurn(Turn turn) {
		Turn output = turn;
		for (Card card : family) {
			output = card.doSideEffectTurnChanges(turn);
		}
		return output;
	}

	public Turn getTurn() {
		for (Card card : family) {
			turn = card.doSideEffectTurnChanges(turn);
		}
		return turn;
	}

	public void discardHand() {
		hand.clear();
	}

	public void changeLocation(int nPlayers) {
		switch(nPlayers) {
			case 2:
				switch (this.location) {
					case "North":
						this.location = "South";
						break;
					case "South":
						this.location = "North";
						break;
				}
				break;
			case 3:
				switch (this.location) {
					case "North":
						this.location = "East";
						break;
					case "East":
						this.location = "South";
						break;
					case "South":
						this.location = "North";
						break;
				}
				break;
			case 4:
				switch (this.location) {
					case "North":
						this.location = "East";
						break;
					case "East":
						this.location = "South";
						break;
					case "South":
						this.location = "West";
						break;
					case "West":
						this.location = "North";
						break;
				}
				break;
		}
	}

	public int getTotalScore() {
		int points = 0;
		for (Card card : this.family) {
			if (!card.isAlive()) {
				points += card.getTotalPoints();
			}
		}
		return points;
	}

	@Override
	public int compareTo(Object arg0) {
		int mePoints = this.getTotalScore();
		Player oPlayer = (Player) arg0;
		int otherPoints = oPlayer.getTotalScore();
		if (mePoints > otherPoints) {
			return -1;
		}
		if (mePoints == otherPoints) {
			return 0;
		}
		return 1;

	}
	
	public void changeDrawLimit(int delta) {
		drawLimit += delta;
	}

	public void forceAddToHand(Card card) {
		hand.add(card);
	}


	public int countNumberOfDuckIconsActive() {
		int count = 0;
		for(Card card : family) {
			if(card.getStoryIconString().contentEquals("Duck")) {
				count++;
			}
		}
		return count;
	}

	public void discardCards(int i) {
		if(hand.size()==0) {
			return; 
		}
		int count = 0; 
		while(count<i && hand.size()!=0) {
			hand.remove(0); 
			count++; 
		}
		
	}
	
	

	

}
