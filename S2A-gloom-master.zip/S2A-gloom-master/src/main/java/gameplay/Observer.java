package gameplay;
import cards.Card;

public interface Observer {

	public void updateCardPlayed(Card played, Card playedOn);
	
}
