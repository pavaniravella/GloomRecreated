package gameplay;

import java.util.List;

import cards.Card;

public class DrawCardsOnSetupTurn extends Turn {
	
	int numberOfCards;
	Turn innerTurn;
	List<Card> deck;

	public DrawCardsOnSetupTurn(int numberOfCards, Turn innerTurn) {
		super(innerTurn.player, innerTurn.guiController, innerTurn.players, innerTurn.subject);
		this.innerTurn = innerTurn;
		this.numberOfCards = numberOfCards;
	}

	@Override
	public void doPreTurnOperations(List<Card> deck, List<Player> players, Player player) {
		for(int i = 0; i < numberOfCards; i++) {
			Card card = deck.remove(0);
			player.forceAddToHand(card);
		}
		innerTurn.doPreTurnOperations(deck, players, player);
	}

}
