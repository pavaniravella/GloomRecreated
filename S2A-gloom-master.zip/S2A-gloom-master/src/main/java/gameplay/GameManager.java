package gameplay;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import cards.Card;
import data.CardAccessor;
import effects.EffectFactory;
import gui.MainGameGUI;
import gui.ScoresGUI;
import gui.StartScreenGUI;

public class GameManager implements Subject {

	private final int NUM_CHARACTERS = 5;

	MainGameGUI guiController;
	ScoresGUI scoresGUI;
	StartScreenGUI startGUI;
	int locale;
	List<Card> deck;
	List<Card> characters;
	List<Player> players = new LinkedList<Player>();
	List<Observer> observers = new ArrayList<Observer>();

	public GameManager(StartScreenGUI startGUI, MainGameGUI guiController, ScoresGUI scoresGUI) {
		this.startGUI = startGUI;
		this.scoresGUI = scoresGUI;
		this.guiController = guiController;
		locale = 0;
	}

	public void setupGame() {
		String[] locations = new String[] { "South", "North", "East", "West", "North2" };
		List<String> playersAsStrings = startGUI.displayStartScreen();
		locale = startGUI.getSelectedLocale();
		guiController.setLocale(locale);
		
		EffectFactory effectFactory = new EffectFactory();
		CardAccessor cardAccessor = new CardAccessor("./src/cards/", effectFactory, locale);
		characters = cardAccessor.getCharacterCards();
		deck = createDeck(cardAccessor);
		
		List<Player> players = new ArrayList<Player>();
		for(int i = 0; i < playersAsStrings.size(); i++) {
			players.add(createPlayer(playersAsStrings.get(i), locations[i]));
		}
		this.players = players;
	}

	public void runGame() {
		int playerTurn = 0;
		Turn currentTurn = getTurn(playerTurn);
		while (!currentTurn.isGameOver()) {
			doPlayerTurn(currentTurn);
			currentTurn.doDrawPhase(deck);
			players = changePlayerLocations(players);
			playerTurn++;
			currentTurn = getTurn(playerTurn);
		}
		String[] names = this.getFinalPlayerOrder();
		int[] scores = this.getFinalScores();
		guiController.endGame();
		scoresGUI.displayScores(names, scores);
	}
	
	Turn getTurn(int playerTurn) {
		Player player = players.get(playerTurn % players.size());
		Turn baseTurn = new StandardTurn(player, guiController, players, this);
		Turn output = player.modifyTurn(baseTurn);
		output.doPreTurnOperations(deck, players, player);
		return output;
	}
	
	public List<Player> changePlayerLocations(List<Player> beforeSwitchPlayers) {
		List<Player> updatedPlayers = new LinkedList<Player>();
		for(int i = 0; i < beforeSwitchPlayers.size(); i++) {
			beforeSwitchPlayers.get(i).changeLocation(beforeSwitchPlayers.size());
			updatedPlayers.add(beforeSwitchPlayers.get(i));
		}
		return updatedPlayers;
	}

	void doPlayerTurn(Turn turn) {
		turn.doFirstTurn();
		if(turn.isGameOver() || turn.isSkipped) {
			return;
		}
		turn.doSecondTurn();
	}

	public int getDeckSize() {
		return deck.size();
	}

	public int getNumberOfPlayers() {
		return this.players.size();
	}

	@Override
	public void notifyCardPlayed(Card played, Card playedOn) {
		for (Observer observer : observers) {
			observer.updateCardPlayed(played, playedOn);
		}
	}

	@Override
	public void registerObserver(Observer observer) {
		observers.add(observer);
	}

	@Override
	public void deregisterObserver(Observer observer) {
		observers.remove(observer);
	}

	List<Card> createDeck(CardAccessor cardAccessor) {
		ArrayList<Card> deck = new ArrayList<Card>();
		List<Card> untimelyDeathCards = cardAccessor.getUntimelyDeathCards();
		List<Card> modifierCards = cardAccessor.getModifierCards();
		//List<Card> eventCards = cardAccessor.getEventCards(); 
		//deck.addAll(eventCards); 
		deck.addAll(untimelyDeathCards);
		deck.addAll(modifierCards);
		return shuffleDeck(deck);
	}
	
	List<Card> shuffleDeck(List<Card> deck){
		Collections.shuffle(deck);
		return deck;
	}

	List<Card> createHand() {
		List<Card> list = new LinkedList<Card>();
		for (int i = 0; i < 5; i++) {
			list.add(deck.remove(0));
		}
		return list;
	}

	Player createPlayer(String name, String placeOnScreen) {
		List<Card> playerFamily = new ArrayList<Card>();
		for (int i = 0; i < NUM_CHARACTERS; i++) {
			Card nextCharacter = characters.remove(0);
			playerFamily.add(nextCharacter);
		}

		List<Card> playerHand = createHand();
		Player player = new Player(name, playerFamily, playerHand, guiController, placeOnScreen);
		registerObserver(player);
		return player;
	}

	public int[] getFinalScores() {
		Collections.sort(this.players);
		Collections.reverse(this.players);
		int[] scores = new int[players.size()];
		for(int i = 0; i < this.players.size(); i++) {
			scores[i] = players.get(i).getTotalScore();
		}
		return scores;
	}

	public String[] getFinalPlayerOrder() {	
		Collections.sort(this.players);
		Collections.reverse(this.players);
		String[] names = new String[players.size()];
		for(int i = 0; i < this.players.size(); i++) {
			names[i] = players.get(i).getPlayerName();
		}
		return names;
	}

}
