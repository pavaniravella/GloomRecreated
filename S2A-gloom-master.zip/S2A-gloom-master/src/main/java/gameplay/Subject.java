package gameplay;
import cards.Card;

public interface Subject {

	public void notifyCardPlayed(Card played, Card playedOn);
	public void registerObserver(Observer observer);
	public void deregisterObserver(Observer observer);
	
}
