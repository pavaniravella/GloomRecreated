package gameplay;

import data.CardAccessor;
import effects.EffectFactory;
import gui.MainGameGUI;
import gui.ScoresGUI;
import gui.StartScreenGUI;

public class Main {

	public static void main(String[] args) {
		MainGameGUI gameController = new MainGameGUI();
		ScoresGUI scoresGUI = new ScoresGUI();
		StartScreenGUI startGUI = new StartScreenGUI();
		GameManager game = new GameManager(startGUI, gameController, scoresGUI);
		game.setupGame();
		game.runGame();
	}
}
