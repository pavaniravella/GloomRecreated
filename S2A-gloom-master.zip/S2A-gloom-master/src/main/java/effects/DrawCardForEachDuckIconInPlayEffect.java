package effects;

import gameplay.DrawCardsOnSetupTurn;
import gameplay.Player;
import gameplay.Turn;

public class DrawCardForEachDuckIconInPlayEffect implements Effect {

	@Override
	public Turn modifyTurn(Turn turn) {
		int ducksInPlay = turn.countNumberDuckIconsInPlay();
		return new DrawCardsOnSetupTurn(ducksInPlay, turn);
	}

	@Override
	public void doImmediateEffect(Player player) {

	}

	@Override
	public void endEffect(Player player) {

	}

}
