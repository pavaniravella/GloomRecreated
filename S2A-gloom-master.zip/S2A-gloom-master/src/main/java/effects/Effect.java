package effects;

import gameplay.Player;
import gameplay.Turn;

public interface Effect {

	Turn modifyTurn(Turn turn);
	
	void doImmediateEffect(Player player);

	void endEffect(Player player);

}
