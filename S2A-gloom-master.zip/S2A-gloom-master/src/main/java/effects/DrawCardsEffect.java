package effects;

import gameplay.DrawCardsOnSetupTurn;
import gameplay.Player;
import gameplay.Turn;

public class DrawCardsEffect implements Effect {
	
	int numberOfCards;
	
	public DrawCardsEffect(int numberOfCards) {
		this.numberOfCards = numberOfCards;
	}

	@Override
	public Turn modifyTurn(Turn turn) {
		return new DrawCardsOnSetupTurn(numberOfCards, turn);
	}

	@Override
	public void doImmediateEffect(Player player) {}

	@Override
	public void endEffect(Player player) {}

}
