package effects;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import gameplay.Player;
import gameplay.Turn;

public class CompositeEffect implements Effect {
	
	List<Effect> effects = new ArrayList<Effect>();
	
	public CompositeEffect(Effect effect, Effect ... effects) {
		this.effects.add(effect);
		this.effects.addAll(Arrays.asList(effects));
	}

	@Override
	public Turn modifyTurn(Turn turn) {
		Turn output = turn;
		for(Effect effect : effects) {
			output = effect.modifyTurn(output);
		}
		return output;
	}

	@Override
	public void doImmediateEffect(Player player) {
		for(Effect effect : effects) {
			effect.doImmediateEffect(player);
		}
	}

	@Override
	public void endEffect(Player player) {
		for(Effect effect : effects) {
			effect.endEffect(player);
		}
	}

}
