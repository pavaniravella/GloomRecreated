package effects;

import gameplay.Player;
import gameplay.Turn;

public class ChangeDrawLimitEffect implements Effect {
	
	int delta;
	
	public ChangeDrawLimitEffect(int delta) {
		this.delta = delta;
	}

	@Override
	public Turn modifyTurn(Turn turn) {
		return turn;
	}

	@Override
	public void doImmediateEffect(Player player) {
		player.changeDrawLimit(delta);
	}

	@Override
	public void endEffect(Player player) {
		player.changeDrawLimit(-1 * delta);
	}

}
