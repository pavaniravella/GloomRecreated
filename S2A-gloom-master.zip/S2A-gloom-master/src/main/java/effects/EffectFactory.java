package effects;

public class EffectFactory {

	public Effect getEffect(String string) {
		switch(string) {
		case "SkipDrawPhase":
			return new SkipDrawPhaseEffect();
		case "DiscardHand":
			return new DiscardHandEffect();
		case "DiscardHandAndSkipDrawPhase":
			return new CompositeEffect(new SkipDrawPhaseEffect(), new DiscardHandEffect());
		case "IncreaseDrawLimitEffect":
			return new ChangeDrawLimitEffect(1);
		case "DecreaseDrawLimitEffect":
			return new ChangeDrawLimitEffect(-1);
		case "DiscardOneCard":
			return new DiscardCardsEffect(1);
		case "DiscardThreeCards":
			return new DiscardCardsEffect(3);
		case "DrawTwoCards":
			return new DrawCardsEffect(2);
		case "DrawThreeCards": 
			return new DrawCardsEffect(3);
		case "DrawOneCardForEachDuckIconInPlay":
			return new DrawCardForEachDuckIconInPlayEffect();
		default:
			return new DoNothingEffect();
		}
	}

}
