package effects;

import gameplay.Player;
import gameplay.Turn;

public class DoNothingEffect implements Effect {

	@Override
	public Turn modifyTurn(Turn turn) {
		return turn;
	}

	@Override
	public void endEffect(Player player) {}

	@Override
	public void doImmediateEffect(Player player) {}

}
