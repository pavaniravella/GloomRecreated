package effects;

import gameplay.Player;
import gameplay.SkipDrawPhaseTurn;
import gameplay.Turn;

public class SkipDrawPhaseEffect implements Effect {

	boolean hasTriggered;
	
	public SkipDrawPhaseEffect() {
		this.hasTriggered = false;
	}
	
	@Override
	public Turn modifyTurn(Turn turn) {
		if(hasTriggered) {
			return turn;
		} else {
			hasTriggered = true;
			return new SkipDrawPhaseTurn(turn);
		}
	}

	@Override
	public void endEffect(Player player) {}

	@Override
	public void doImmediateEffect(Player player) {}


}
