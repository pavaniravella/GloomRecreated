package effects;

import gameplay.Player;
import gameplay.Turn;

public class DiscardCardsEffect implements Effect {
	
	int numberOfCards;
	
	public DiscardCardsEffect(int numberOfCards) {
		this.numberOfCards = numberOfCards;
	}

	@Override
	public Turn modifyTurn(Turn turn) {
		return turn;
	}

	@Override
	public void doImmediateEffect(Player player) {
		player.discardCards(numberOfCards);
	}

	@Override
	public void endEffect(Player player) {

	}

}
