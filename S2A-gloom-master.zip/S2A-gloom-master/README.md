# S2A-Gloom
Our project will be considered done when the project has:
- A main page that has the ability to play the game or check the rules
- Graphical depictions of all 20 Character Cards of the original game
- Graphical depictions of all 57 Modifier Cards of the original game
- Graphical depictions of all 11 Event Cards of the original game
- Graphical depictions of all 20 Untimely Death Cards of the original game
- A GUI to play the game
- An end screen displaying who won and other game results
- A chat section to simulate the “storytelling” aspect of the game
- Thorough and well-written testing framework with no errors
- Handled the following edge cases: 
  - The player cannot choose more than allowed cards 
  - The game ends the instant the person with the lowest self-worth points, and the last family member dies *tricky*
  - Cannot allow the player to make less than or more than 2 plays 
  - Characters that are alive cannot have self-worth points 
  - Empty deck and hand
  - Limit the ability to draw cards if the current card amount is above draw limit
  - Can only have anywhere from 2-5 players in a game
  - Cannot make any more 2 standard plays in a turn
  - Can make additional free plays if cards are considered free plays
  - Distinguish between free plays and standard play 
  - Family cannot contain more than 5 cards or less than 4 cards
  - If a player ends the game on their first play of a turn by killing their last family member, the game is immediately over and no other standard or free play can be done during their turn
  - Effects that cancel each other out

Our project will be considered done when the following rules have been implemented:
- At the beginning of the game, players choose a family
- Players draw a starting hand of 5 cards (where a hand is a random draw of Modifier, Untimely Death, and Event Cards)
- On their turn, players make up to 2 of the following plays, or pass (one or both turns):
  - Play a modifier, event, or death card
    - Modifier: can contribute to a story and/or add self-worth points
    - Event: reveals an event, follow the instructions on the hard
    - Death: kill any of the player’s characters with a negative self-worth score
  - Each card may also have an effect on the game state
    - Immediate Effect: Become active as soon as the card is placed down. Shifting of the card does not re-trigger the effect
    - Response Effect: Used during another’s players turn in response to a play
    - Continuous Effect: Similar to immediate effects but when shifted to new characters the effect now works on the new character
  - Discard their entire hand (which effectively ends their turn)
- After a player’s turn
  - A player can draw Modifier, Event, and Untimely Death Cards up to their draw limit (which is defaulted to 5 unless changed by effect cards) into their hand
  - The player to the current player’s left begins their turn


