**Logistics:**

  1. When will a formal code inspection be warranted?



*   A formal code inspection is warranted before each release (Milestone due)
*   A much less formal code inspection is warranted on each merge to our master branch

  2. Who will take the lead on moderating inspections?



*   Since we all will have made changes to the codebase at the time of a formal code inspection, nobody will be able to be completely unbiased.  Everyone will have to take part in moderating the inspections, particularly when they are not “attached” to a change that is being reviewed.

  3. How will you share the results of inspections?



*   For formal inspections, every team member will be present, so they will immediately know the results of the inspection.  For informal inspections on merges to master, notes will be saved by our source control system.

**Criteria:**

  4. What are the key "code smells" from each chapter of Clean Code? This is the big question. Chapter 17 of Clean Code might help you recall them.



*   Ch 2 Names
    *   Choose descriptive names
    *   Choose names at the appropriate level of abstraction
    *   Use standard nomenclature where possible
    *   Use unambiguous names
    *   Use long names for long scopes
    *   Avoid encodings
    *   Names should describe side effects
*   Ch 3 Functions
    *   Functions should have a small number of arguments
    *   Avoid output arguments
    *   Avoid flag arguments
    *   Remove dead functions
    *   Find and eliminate duplication wherever possible
    *   Avoid “feature envy” (i.e. train wrecks)
    *   Avoid selector arguments
    *   Prefer polymorphism to if/else or switch/case
    *   Encapsulate conditionals
    *   Avoid negative conditionals
    *   Functions should do one thing
    *   Encapsulate boundary conditions
    *   Functions should only descend one level of abstraction
*   Ch 4 Comments
    *   Avoid the following:
        *   Inappropriate comments
        *   Obsolete comments
        *   Redundant comments
        *   Poorly-written comments
        *   Commented-out code
*   Ch 5 Formatting
    *   Avoid the following:
        *   No blank lines to separate the functions
        *   Break the vertically dense
        *   Declare variables far from their usage
        *   Not declaring instance variable at the top of the class
        *   Make dependent functions far from each other and make the caller below the callee
        *   Create a long vertical distance between strong conceptual affinity classes
        *   Not consistent with indentation and formating with the group
*   Ch 6 Demeter
    *   Objects hide their data between abstractions and expose functions to operate the data. 
    *   Data structures expose their data
    *   Methods should only call methods of objects that are arguments to the method, fields of the containing class, or objects that the method instantiates
    *   Law of Demeter says that a module should not know about the details of the objects it manipulates 
    *   Train wrecks should not happen
    *   Objects should expose behavior and hide data. 
*   Ch 7 Error Handling
    *   Use exceptions rather than return codes
    *   Use unchecked exceptions
    *   Provide context with exceptions
    *   Define exception classes in terms of a caller’s needs
    *   Don’t return null
    *   Don’t pass null
*   Ch 9 Unit Testing
    *   Avoid insufficient tests
    *   Use a coverage tool
    *   Don’t skip trivial tests
    *   Consider ignored testing conventions with regard to its ambiguity
    *   Test boundary conditions
    *   Exhaustively test near bugs
    *   Consider reasons for patterns of failure, including test coverage patterns
    *   Write fast tests
*   Ch 10 Classes
    *   Classes should be encapsulated 
    *   Classes should be small 
        *   Don’t create any god classes 
    *   Each class should have single responsibility and only one reason to change 
        *   The reason to change is to full fill the responsibility 
        *   The reasons of change help with abstraction of code. 
    *   Classes should have a small number of instance variables
    *   Maintaining cohesion might result in many small classes 
    *   Each method in a class should manipulate one or more of those variables 
    *   Classes should be constantly reorganized for change 
        *   If you add a new method and
*   Ch 12 TDD
    *   Follow Martin’s process for TDD:
        *   Write a little test code first until you get a compile/test error.
        *   Write bare minimum code to make the test compile/pass.
        *   Repeat 1-2 until the test is complete.
        *   Commit to the feature branch.
        *   Repeat 1-4 until the feature satisfies BVA.

  5. Will everyone apply all criteria from every chapter from Clean Code? Or will each person specialize in a few criteria?



*   Everyone will apply all of the criteria from every chapter as they code. It is okay to have strengths and weaknesses in certain areas, but we should individually strive to meet all of the criteria and collectively hold each other accountable to the standard.

**Scope:**

  6. Will your team inspect every file in your codebase? Every file you touch in your feature branch? Or something else entirely?



*   We will look at all of the changed files since the previous release.

  7. Of those files, will each person look at every file in consideration? Or will your team assign different files to different people?



*   Each person will look at every file in consideration.  The more eyes we can get on the code, the better we will be able to spot problems.

**Tools:**

  8. To what extent can your inspection criteria be automated? Automation will increase your inspection's speed and reliability.



*   We can use mutation tests and unit tests to verify how well our code works at the lowest level. 
*   We can use the pit mutation tests to verify how closely TDD is being followed. 
*   We can also use a checkstyle plugin to verify that our formatting will be consistent.

  9. Which aspects of your inspection criteria will need human intervention?



*   Verifying valid naming conventions is something that will definitely need human intervention.  
*   The principle of least knowledge would also need to be verified by humans.  
*   Most function criteria will need to be manually checked.
*   BVA cases will need to be verified by people.
